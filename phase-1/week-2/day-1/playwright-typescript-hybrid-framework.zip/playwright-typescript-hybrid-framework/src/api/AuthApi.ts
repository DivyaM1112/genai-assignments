import { request } from '@playwright/test';

export class AuthApi {
  async loginApi(username: string, password: string) {
    const context = await request.newContext();

    const response = await context.post('/login', {
      data: {
        username,
        password
      }
    });

    return response;
  }
}