export class DBUtil {
  async connect() {
    console.log('DB Connected');
  }

  async validateData() {
    console.log('DB Validation');
  }
}