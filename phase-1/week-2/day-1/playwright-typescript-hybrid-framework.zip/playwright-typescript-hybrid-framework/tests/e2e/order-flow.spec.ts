import { test, expect } from '@playwright/test';

test('Complete E2E Flow', async ({ page }) => {
  await page.goto('/');
  await expect(page).toHaveTitle(/Mock/);
});