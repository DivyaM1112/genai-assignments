import { test, expect } from '@playwright/test';
import { AuthApi } from '../../src/api/AuthApi';

test.describe('API Authentication', () => {

  test('Login API Success', async () => {
    const api = new AuthApi();

    const response = await api.loginApi('admin', 'password');

    expect(response.status()).toBe(200);
  });

  test('Login API Failure', async () => {
    const api = new AuthApi();

    const response = await api.loginApi('wrong', 'wrong');

    expect(response.status()).toBe(401);
  });

});