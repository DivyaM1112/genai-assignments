import { test, expect } from '@playwright/test';
import { LoginPage } from '../../src/pages/LoginPage';

test.describe('Authentication Tests', () => {

  test('Valid Login', async ({ page }) => {
    const login = new LoginPage(page);

    await page.goto('/');
    await login.login('standard_user', 'secret_sauce');

    await expect(page).toHaveURL(/inventory/);
  });

  test('Invalid Login', async ({ page }) => {
    const login = new LoginPage(page);

    await page.goto('/');
    await login.login('invalid', 'invalid');

    await expect(page.locator('.error-message-container')).toBeVisible();
  });

});