import { Given, When, Then } from '@cucumber/cucumber';

Given('user launches application', async function () {
  console.log('Launching app');
});

When('user enters valid credentials', async function () {
  console.log('Entering credentials');
});

Then('user should login successfully', async function () {
  console.log('Login successful');
});