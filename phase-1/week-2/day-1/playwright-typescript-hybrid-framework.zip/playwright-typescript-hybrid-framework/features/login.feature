Feature: Login Feature

  Scenario: Successful Login
    Given user launches application
    When user enters valid credentials
    Then user should login successfully