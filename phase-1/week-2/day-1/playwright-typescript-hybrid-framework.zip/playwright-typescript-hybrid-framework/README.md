# Playwright TypeScript Hybrid Framework

## Overview
Enterprise-grade Playwright TypeScript Hybrid Automation Framework supporting:
- UI Testing
- API Testing
- Playwright Test Runner
- Cucumber BDD
- Cross-browser execution
- CI/CD integration
- Docker support
- Reporting
- Logging
- Data-driven execution

## Tech Stack
- Playwright
- TypeScript
- Cucumber
- Axios (optional extension)
- Extent Reports
- Faker
- dotenv
- ExcelJS
- Winston-style custom logger

## Features
- Parallel execution
- Retry mechanism
- Screenshot/video capture
- API schema validation
- DB utility support
- Docker support
- Multi-environment execution
- Tag-based execution
- Smoke/Regression/Sanity suites
- Visual testing support
- Accessibility testing
- Network mocking
- Authentication/session reuse

## Project Structure

```bash
playwright-typescript-hybrid-framework/
│
├── src/
│   ├── api/
│   ├── pages/
│   ├── utils/
│   ├── fixtures/
│   ├── config/
│   ├── data/
│   └── database/
│
├── tests/
│   ├── ui/
│   ├── api/
│   └── e2e/
│
├── features/
├── step-definitions/
├── reports/
├── logs/
├── .github/workflows/
├── docker/
└── README.md
```

## Installation

```bash
npm install
```

## Run Tests

### UI Tests
```bash
npm run test:ui
```

### API Tests
```bash
npm run test:api
```

### Regression Suite
```bash
npm run test:regression
```

### Cucumber Tests
```bash
npm run cucumber
```

## Docker Execution

```bash
docker-compose up --build
```

## GitHub Actions
GitHub Actions workflow available under:
`.github/workflows/playwright.yml`

## Reporting
Extent reports generated under:
`reports/extent-report.html`

## Environment Variables
Supported through:
- .env
- config.ts

## Sample Coverage
- Authentication scenarios
- Positive and negative API validations
- Edge case validations
- End-to-end scenarios
- Session handling
- Data-driven tests