# Quick Start Guide

This guide will help you get started with the Playwright E-Commerce Test Automation Framework in 5 minutes.

## Prerequisites

- Node.js (v18+)
- npm (v8+)

## Steps

### 1. Install Dependencies

```bash
npm install
```

### 2. Install Browsers

```bash
npm run install:browsers
```

### 3. Configure Environment (Optional)

```bash
cp .env.example .env
```

Edit `.env` file with your application URLs and credentials.

### 4. Run Tests

#### All Tests
```bash
npm test
```

#### Specific Test Suite
```bash
# Authentication tests
npm run test:auth

# API tests
npm run test:api

# All E2E tests
npm run test:e2e
```

#### Interactive UI Mode
```bash
npm run test:ui
```

### 5. View Reports

```bash
npm run report
```

## Test Execution Examples

```bash
# Run on specific browser
npm run test:chrome

# Run in headed mode (see browser)
npm run test:headed

# Run in debug mode
npm run test:debug

# Run for specific environment
npm run test:staging
```

## Project Structure Overview

```
src/
├── pages/          → Page Objects (LoginPage, CartPage, etc.)
├── helpers/        → Helper utilities (ApiHelper, WaitHelper)
├── utils/          → Common utilities (Logger, DataGenerator)
└── config/         → Environment configurations

tests/
├── e2e/            → UI tests (auth, products, cart, checkout)
└── api/            → API tests (auth, products, cart)
```

## Writing Your First Test

```typescript
import { test, expect } from '@playwright/test';
import { LoginPage } from '../../src/pages/login.page';

test('My First Test', async ({ page }) => {
  const loginPage = new LoginPage(page);
  
  await loginPage.navigateToLogin();
  await loginPage.login('test@example.com', 'password');
  
  const isLoggedIn = await loginPage.isLoggedIn();
  expect(isLoggedIn).toBeTruthy();
});
```

## Tips

- ✅ Use Page Objects for UI interactions
- ✅ Use ApiHelper for API requests
- ✅ Use Logger for consistent logging
- ✅ Use DataGenerator for test data
- ✅ Check README.md for detailed documentation

## Need Help?

- Check the full README.md
- Review existing test cases
- Check Playwright documentation: https://playwright.dev

Happy Testing! 🎉
