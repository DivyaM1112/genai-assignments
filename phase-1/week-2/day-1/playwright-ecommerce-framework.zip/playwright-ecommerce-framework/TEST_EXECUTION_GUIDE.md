# Test Execution Guide

## Overview

This document provides detailed instructions for executing tests in the Playwright E-Commerce Test Automation Framework.

---

## Table of Contents

1. [Basic Test Execution](#basic-test-execution)
2. [Advanced Test Execution](#advanced-test-execution)
3. [Environment-Specific Execution](#environment-specific-execution)
4. [Parallel Execution](#parallel-execution)
5. [Debugging Tests](#debugging-tests)
6. [Reporting](#reporting)

---

## Basic Test Execution

### Run All Tests

```bash
npm test
```

### Run Tests with UI Mode

```bash
npm run test:ui
```

This opens an interactive UI where you can:
- Select specific tests to run
- See test execution in real-time
- Time-travel through test steps
- Inspect locators

### Run Tests in Headed Mode

```bash
npm run test:headed
```

This runs tests with browsers visible (non-headless mode).

---

## Advanced Test Execution

### Run Specific Test File

```bash
npx playwright test tests/e2e/auth/login.spec.ts
```

### Run Specific Test Case

```bash
npx playwright test -g "TC001"
```

### Run Multiple Specific Tests

```bash
npx playwright test -g "TC001|TC002|TC003"
```

### Run Tests by Tag (if implemented)

```bash
npx playwright test --grep @smoke
npx playwright test --grep @regression
npx playwright test --grep-invert @skip
```

### Run Only Failed Tests

```bash
npx playwright test --last-failed
```

---

## Environment-Specific Execution

### Development Environment

```bash
npm run test:dev
```

or

```bash
ENV=dev npx playwright test
```

### Staging Environment

```bash
npm run test:staging
```

or

```bash
ENV=staging npx playwright test
```

### Production Environment

```bash
npm run test:prod
```

or

```bash
ENV=prod npx playwright test
```

---

## Browser-Specific Execution

### Run on Chromium Only

```bash
npm run test:chrome
```

or

```bash
npx playwright test --project=chromium
```

### Run on Firefox Only

```bash
npm run test:firefox
```

or

```bash
npx playwright test --project=firefox
```

### Run on WebKit Only

```bash
npm run test:webkit
```

or

```bash
npx playwright test --project=webkit
```

### Run on Mobile Chrome

```bash
npx playwright test --project=mobile-chrome
```

### Run on Mobile Safari

```bash
npx playwright test --project=mobile-safari
```

### Run on All Browsers

```bash
npx playwright test --project=chromium --project=firefox --project=webkit
```

---

## Test Suite-Specific Execution

### Authentication Tests Only

```bash
npm run test:auth
```

or

```bash
npx playwright test tests/e2e/auth/
```

### Product Tests Only

```bash
npx playwright test tests/e2e/products/
```

### Cart Tests Only

```bash
npx playwright test tests/e2e/cart/
```

### Checkout Tests Only

```bash
npx playwright test tests/e2e/checkout/
```

### All API Tests

```bash
npm run test:api
```

or

```bash
npx playwright test tests/api/
```

### All E2E Tests

```bash
npm run test:e2e
```

or

```bash
npx playwright test tests/e2e/
```

---

## Parallel Execution

### Run Tests in Parallel (Default)

```bash
npx playwright test --workers=4
```

### Run Tests Sequentially

```bash
npx playwright test --workers=1
```

### Run Tests with Maximum Workers

```bash
npx playwright test --workers=100%
```

### Run Specific File with Multiple Workers

```bash
npx playwright test tests/e2e/auth/login.spec.ts --workers=2
```

---

## Debugging Tests

### Debug Mode (Step Through)

```bash
npm run test:debug
```

or

```bash
npx playwright test --debug
```

This opens Playwright Inspector where you can:
- Step through each test action
- See locators highlighted
- Edit locators on the fly
- Generate code

### Debug Specific Test

```bash
npx playwright test tests/e2e/auth/login.spec.ts --debug
```

### Debug with Browser Console

```bash
PWDEBUG=console npx playwright test
```

### Enable Verbose Logging

```bash
DEBUG=pw:api npx playwright test
```

### Run with Trace

```bash
npx playwright test --trace on
```

Then view trace:

```bash
npx playwright show-trace trace.zip
```

---

## Test Options and Flags

### Retry Failed Tests

```bash
npx playwright test --retries=2
```

### Set Timeout

```bash
npx playwright test --timeout=60000
```

### Update Snapshots

```bash
npx playwright test --update-snapshots
```

### Run Specific Number of Times

```bash
npx playwright test --repeat-each=3
```

### Shard Tests (for distributed execution)

```bash
# Run first shard
npx playwright test --shard=1/3

# Run second shard
npx playwright test --shard=2/3

# Run third shard
npx playwright test --shard=3/3
```

---

## Reporting

### View HTML Report

```bash
npm run report
```

or

```bash
npx playwright show-report
```

### Generate Report Without Opening

```bash
npx playwright test --reporter=html
```

### Generate Multiple Reports

```bash
npx playwright test --reporter=html,json,junit
```

### List Reporter (Console Output)

```bash
npx playwright test --reporter=list
```

### Line Reporter (Minimal Output)

```bash
npx playwright test --reporter=line
```

### Dot Reporter

```bash
npx playwright test --reporter=dot
```

---

## Configuration Overrides

### Override Base URL

```bash
npx playwright test --config=playwright.config.ts --base-url=https://custom-url.com
```

### Use Custom Config File

```bash
npx playwright test --config=playwright.custom.config.ts
```

### Ignore Config File

```bash
npx playwright test --ignore-snapshots
```

---

## CI/CD Execution

### GitHub Actions

The framework includes a GitHub Actions workflow. Tests run automatically on:
- Push to main/develop branches
- Pull requests
- Daily schedule (2 AM UTC)

### Jenkins

```groovy
stage('Run Tests') {
    steps {
        sh 'npm ci'
        sh 'npx playwright install --with-deps'
        sh 'npm test'
    }
}
```

### GitLab CI

```yaml
test:
  image: mcr.microsoft.com/playwright:v1.42.0-focal
  script:
    - npm ci
    - npm test
  artifacts:
    when: always
    paths:
      - playwright-report/
      - test-results/
```

---

## Performance Tips

1. **Use Parallelization**: Run tests in parallel for faster execution
2. **Run Critical Tests First**: Use `--grep` to run smoke tests first
3. **Skip Visual Tests in CI**: Use headless mode in CI/CD
4. **Optimize Wait Strategies**: Avoid unnecessary waits
5. **Use Sharding**: Distribute tests across multiple machines

---

## Troubleshooting Execution Issues

### Tests Not Running

```bash
# Clean install
rm -rf node_modules package-lock.json
npm install
npx playwright install --with-deps
```

### Timeout Issues

```bash
# Increase timeout
npx playwright test --timeout=90000
```

### Browser Issues

```bash
# Reinstall browsers
npx playwright install --force
```

### Port Conflicts

```bash
# Use different port for UI mode
npx playwright test --ui-port=8080
```

---

## Best Practices

1. **Run smoke tests before full suite**: `npx playwright test --grep @smoke`
2. **Use appropriate workers**: Don't over-parallelize on limited resources
3. **Enable retries in CI**: `--retries=2` for flaky test handling
4. **Generate traces on failures**: Helps with debugging
5. **Use headed mode for development**: See what's happening
6. **Use UI mode for test creation**: Interactive test development

---

For more information, refer to:
- [Playwright Documentation](https://playwright.dev/)
- [Framework README](./README.md)
- [Quick Start Guide](./QUICKSTART.md)

---

**Last Updated**: December 2024
