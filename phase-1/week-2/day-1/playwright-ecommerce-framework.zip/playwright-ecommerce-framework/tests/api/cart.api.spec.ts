import { test, expect } from '@playwright/test';
import { ApiHelper } from '../../../src/helpers/api.helper';
import { config } from '../../../src/config/environment.config';
import { Logger } from '../../../src/utils/logger';

test.describe('API Cart Tests', () => {
  let apiHelper: ApiHelper;
  let authToken: string;
  const apiBaseUrl = config.apiUrl;

  test.beforeAll(async ({ request }) => {
    // Get auth token
    const loginResponse = await request.post(`${apiBaseUrl}/auth/login`, {
      data: {
        email: config.credentials.validUser.email,
        password: config.credentials.validUser.password,
      },
    });
    const body = await loginResponse.json();
    authToken = body.token;
  });

  test.beforeEach(async ({ request }) => {
    apiHelper = new ApiHelper(request);
  });

  test('API_TC021 - Get Empty Cart', async ({ request }) => {
    Logger.info('API Test: Get Empty Cart');

    const response = await request.get(`${apiBaseUrl}/cart`, {
      headers: {
        Authorization: `Bearer ${authToken}`,
      },
    });

    expect(response.status()).toBe(200);

    const body = await response.json();
    expect(body).toHaveProperty('items');
    expect(Array.isArray(body.items)).toBeTruthy();

    Logger.success('Empty cart retrieved successfully');
  });

  test('API_TC022 - Add Item to Cart', async ({ request }) => {
    Logger.info('API Test: Add Item to Cart');

    const cartItem = {
      productId: 1,
      quantity: 2,
    };

    const response = await request.post(`${apiBaseUrl}/cart/items`, {
      data: cartItem,
      headers: {
        Authorization: `Bearer ${authToken}`,
      },
    });

    expect(response.status()).toBe(201);

    const body = await response.json();
    expect(body).toHaveProperty('productId', cartItem.productId);
    expect(body).toHaveProperty('quantity', cartItem.quantity);

    Logger.success('Item added to cart successfully');
  });

  test('API_TC023 - Add Multiple Items to Cart', async ({ request }) => {
    Logger.info('API Test: Add Multiple Items to Cart');

    const items = [
      { productId: 1, quantity: 1 },
      { productId: 2, quantity: 2 },
      { productId: 3, quantity: 3 },
    ];

    for (const item of items) {
      await request.post(`${apiBaseUrl}/cart/items`, {
        data: item,
        headers: {
          Authorization: `Bearer ${authToken}`,
        },
      });
    }

    const response = await request.get(`${apiBaseUrl}/cart`, {
      headers: {
        Authorization: `Bearer ${authToken}`,
      },
    });

    const body = await response.json();
    expect(body.items.length).toBeGreaterThanOrEqual(items.length);

    Logger.success('Multiple items added to cart successfully');
  });

  test('API_TC024 - Update Cart Item Quantity', async ({ request }) => {
    Logger.info('API Test: Update Cart Item Quantity');

    // First add an item
    const cartItem = {
      productId: 1,
      quantity: 2,
    };

    await request.post(`${apiBaseUrl}/cart/items`, {
      data: cartItem,
      headers: {
        Authorization: `Bearer ${authToken}`,
      },
    });

    // Update quantity
    const updateData = {
      quantity: 5,
    };

    const response = await request.patch(`${apiBaseUrl}/cart/items/${cartItem.productId}`, {
      data: updateData,
      headers: {
        Authorization: `Bearer ${authToken}`,
      },
    });

    expect(response.status()).toBe(200);

    const body = await response.json();
    expect(body).toHaveProperty('quantity', updateData.quantity);

    Logger.success('Cart item quantity updated successfully');
  });

  test('API_TC025 - Remove Item from Cart', async ({ request }) => {
    Logger.info('API Test: Remove Item from Cart');

    // First add an item
    const cartItem = {
      productId: 1,
      quantity: 1,
    };

    await request.post(`${apiBaseUrl}/cart/items`, {
      data: cartItem,
      headers: {
        Authorization: `Bearer ${authToken}`,
      },
    });

    // Remove the item
    const response = await request.delete(`${apiBaseUrl}/cart/items/${cartItem.productId}`, {
      headers: {
        Authorization: `Bearer ${authToken}`,
      },
    });

    expect(response.status()).toBe(200);

    Logger.success('Item removed from cart successfully');
  });

  test('API_TC026 - Clear Entire Cart', async ({ request }) => {
    Logger.info('API Test: Clear Entire Cart');

    // Add some items first
    await request.post(`${apiBaseUrl}/cart/items`, {
      data: { productId: 1, quantity: 2 },
      headers: {
        Authorization: `Bearer ${authToken}`,
      },
    });

    // Clear cart
    const response = await request.delete(`${apiBaseUrl}/cart`, {
      headers: {
        Authorization: `Bearer ${authToken}`,
      },
    });

    expect(response.status()).toBe(200);

    Logger.success('Cart cleared successfully');
  });

  test('API_TC027 - Get Cart Total', async ({ request }) => {
    Logger.info('API Test: Get Cart Total');

    // Add items
    await request.post(`${apiBaseUrl}/cart/items`, {
      data: { productId: 1, quantity: 2 },
      headers: {
        Authorization: `Bearer ${authToken}`,
      },
    });

    // Get cart with totals
    const response = await request.get(`${apiBaseUrl}/cart`, {
      headers: {
        Authorization: `Bearer ${authToken}`,
      },
    });

    const body = await response.json();
    expect(body).toHaveProperty('subtotal');
    expect(body).toHaveProperty('tax');
    expect(body).toHaveProperty('total');
    expect(typeof body.total).toBe('number');

    Logger.success('Cart total calculated correctly');
  });

  test('API_TC028 - Add Item with Invalid Product ID', async ({ request }) => {
    Logger.info('API Test: Add Item with Invalid Product ID');

    const cartItem = {
      productId: 99999,
      quantity: 1,
    };

    const response = await request.post(`${apiBaseUrl}/cart/items`, {
      data: cartItem,
      headers: {
        Authorization: `Bearer ${authToken}`,
      },
    });

    expect(response.status()).toBe(404);

    Logger.success('Invalid product ID rejected correctly');
  });

  test('API_TC029 - Add Item with Zero Quantity', async ({ request }) => {
    Logger.info('API Test: Add Item with Zero Quantity');

    const cartItem = {
      productId: 1,
      quantity: 0,
    };

    const response = await request.post(`${apiBaseUrl}/cart/items`, {
      data: cartItem,
      headers: {
        Authorization: `Bearer ${authToken}`,
      },
    });

    expect(response.status()).toBe(400);

    Logger.success('Zero quantity rejected correctly');
  });

  test('API_TC030 - Add Item with Negative Quantity', async ({ request }) => {
    Logger.info('API Test: Add Item with Negative Quantity');

    const cartItem = {
      productId: 1,
      quantity: -5,
    };

    const response = await request.post(`${apiBaseUrl}/cart/items`, {
      data: cartItem,
      headers: {
        Authorization: `Bearer ${authToken}`,
      },
    });

    expect(response.status()).toBe(400);

    Logger.success('Negative quantity rejected correctly');
  });
});
