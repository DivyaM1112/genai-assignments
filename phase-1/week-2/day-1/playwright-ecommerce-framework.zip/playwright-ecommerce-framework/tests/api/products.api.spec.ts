import { test, expect } from '@playwright/test';
import { ApiHelper } from '../../../src/helpers/api.helper';
import { config } from '../../../src/config/environment.config';
import { Logger } from '../../../src/utils/logger';

test.describe('API Products Tests', () => {
  let apiHelper: ApiHelper;
  let authToken: string;
  const apiBaseUrl = config.apiUrl;

  test.beforeAll(async ({ request }) => {
    // Get auth token for authenticated requests
    const loginResponse = await request.post(`${apiBaseUrl}/auth/login`, {
      data: {
        email: config.credentials.validUser.email,
        password: config.credentials.validUser.password,
      },
    });
    const body = await loginResponse.json();
    authToken = body.token;
  });

  test.beforeEach(async ({ request }) => {
    apiHelper = new ApiHelper(request);
  });

  test('API_TC011 - Get All Products', async () => {
    Logger.info('API Test: Get All Products');

    const response = await apiHelper.get(`${apiBaseUrl}/products`);

    await apiHelper.validateStatusCode(response, 200);

    const body = await apiHelper.getResponseBody(response);
    expect(Array.isArray(body.products)).toBeTruthy();
    expect(body.products.length).toBeGreaterThan(0);

    Logger.success(`Retrieved ${body.products.length} products`);
  });

  test('API_TC012 - Get Product by ID', async () => {
    Logger.info('API Test: Get Product by ID');

    const productId = 1;
    const response = await apiHelper.get(`${apiBaseUrl}/products/${productId}`);

    await apiHelper.validateStatusCode(response, 200);

    const body = await apiHelper.getResponseBody(response);
    expect(body).toHaveProperty('id', productId);
    expect(body).toHaveProperty('name');
    expect(body).toHaveProperty('price');

    Logger.success('Product details retrieved successfully');
  });

  test('API_TC013 - Get Non-Existent Product', async () => {
    Logger.info('API Test: Get Non-Existent Product');

    const productId = 99999;
    const response = await apiHelper.get(`${apiBaseUrl}/products/${productId}`);

    await apiHelper.validateStatusCode(response, 404);

    const body = await apiHelper.getResponseBody(response);
    expect(body).toHaveProperty('error');

    Logger.success('Non-existent product returned 404 error');
  });

  test('API_TC014 - Search Products by Name', async () => {
    Logger.info('API Test: Search Products by Name');

    const searchTerm = 'laptop';
    const response = await apiHelper.get(`${apiBaseUrl}/products/search?q=${searchTerm}`);

    await apiHelper.validateStatusCode(response, 200);

    const body = await apiHelper.getResponseBody(response);
    expect(Array.isArray(body.products)).toBeTruthy();

    Logger.success('Product search completed successfully');
  });

  test('API_TC015 - Filter Products by Category', async () => {
    Logger.info('API Test: Filter Products by Category');

    const category = 'electronics';
    const response = await apiHelper.get(`${apiBaseUrl}/products?category=${category}`);

    await apiHelper.validateStatusCode(response, 200);

    const body = await apiHelper.getResponseBody(response);
    expect(Array.isArray(body.products)).toBeTruthy();

    Logger.success('Products filtered by category successfully');
  });

  test('API_TC016 - Sort Products by Price', async () => {
    Logger.info('API Test: Sort Products by Price');

    const response = await apiHelper.get(`${apiBaseUrl}/products?sort=price&order=asc`);

    await apiHelper.validateStatusCode(response, 200);

    const body = await apiHelper.getResponseBody(response);
    expect(Array.isArray(body.products)).toBeTruthy();

    Logger.success('Products sorted by price successfully');
  });

  test('API_TC017 - Get Products with Pagination', async () => {
    Logger.info('API Test: Get Products with Pagination');

    const page = 1;
    const limit = 10;
    const response = await apiHelper.get(`${apiBaseUrl}/products?page=${page}&limit=${limit}`);

    await apiHelper.validateStatusCode(response, 200);

    const body = await apiHelper.getResponseBody(response);
    expect(body).toHaveProperty('products');
    expect(body).toHaveProperty('page', page);
    expect(body).toHaveProperty('limit', limit);
    expect(body.products.length).toBeLessThanOrEqual(limit);

    Logger.success('Pagination working correctly');
  });

  test('API_TC018 - Verify Product Schema', async () => {
    Logger.info('API Test: Verify Product Schema');

    const response = await apiHelper.get(`${apiBaseUrl}/products/1`);

    await apiHelper.validateStatusCode(response, 200);

    const expectedSchema = {
      id: 'number',
      name: 'string',
      price: 'number',
      description: 'string',
      category: 'string',
    };

    await apiHelper.validateSchema(response, expectedSchema);

    Logger.success('Product schema validation passed');
  });

  test('API_TC019 - Create Product (Admin)', async ({ request }) => {
    Logger.info('API Test: Create Product (Admin)');

    const newProduct = {
      name: 'Test Product',
      price: 99.99,
      description: 'Test product description',
      category: 'electronics',
      stock: 100,
    };

    const response = await request.post(`${apiBaseUrl}/products`, {
      data: newProduct,
      headers: {
        Authorization: `Bearer ${authToken}`,
      },
    });

    expect(response.status()).toBe(201);

    const body = await response.json();
    expect(body).toHaveProperty('id');
    expect(body).toHaveProperty('name', newProduct.name);

    Logger.success('Product created successfully');
  });

  test('API_TC020 - Update Product (Admin)', async ({ request }) => {
    Logger.info('API Test: Update Product (Admin)');

    const productId = 1;
    const updateData = {
      price: 149.99,
      stock: 50,
    };

    const response = await request.patch(`${apiBaseUrl}/products/${productId}`, {
      data: updateData,
      headers: {
        Authorization: `Bearer ${authToken}`,
      },
    });

    expect(response.status()).toBe(200);

    const body = await response.json();
    expect(body).toHaveProperty('price', updateData.price);

    Logger.success('Product updated successfully');
  });
});
