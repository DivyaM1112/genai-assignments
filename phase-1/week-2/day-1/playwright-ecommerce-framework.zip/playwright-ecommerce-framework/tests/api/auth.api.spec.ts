import { test, expect } from '@playwright/test';
import { ApiHelper } from '../../../src/helpers/api.helper';
import { config } from '../../../src/config/environment.config';
import { Logger } from '../../../src/utils/logger';
import { DataGenerator } from '../../../src/utils/data-generator';

test.describe('API Authentication Tests', () => {
  let apiHelper: ApiHelper;
  const apiBaseUrl = config.apiUrl;

  test.beforeEach(async ({ request }) => {
    apiHelper = new ApiHelper(request);
  });

  test('API_TC001 - Login with Valid Credentials', async () => {
    Logger.info('API Test: Login with Valid Credentials');

    const loginData = {
      email: config.credentials.validUser.email,
      password: config.credentials.validUser.password,
    };

    const response = await apiHelper.post(`${apiBaseUrl}/auth/login`, loginData);

    await apiHelper.validateStatusCode(response, 200);

    const body = await apiHelper.getResponseBody(response);
    expect(body).toHaveProperty('token');
    expect(body.token).toBeTruthy();

    Logger.success('Login API returned valid token');
  });

  test('API_TC002 - Login with Invalid Email', async () => {
    Logger.info('API Test: Login with Invalid Email');

    const loginData = {
      email: DataGenerator.generateRandomEmail(),
      password: config.credentials.validUser.password,
    };

    const response = await apiHelper.post(`${apiBaseUrl}/auth/login`, loginData);

    await apiHelper.validateStatusCode(response, 401);

    const body = await apiHelper.getResponseBody(response);
    expect(body).toHaveProperty('error');

    Logger.success('Invalid email returned 401 error');
  });

  test('API_TC003 - Login with Invalid Password', async () => {
    Logger.info('API Test: Login with Invalid Password');

    const loginData = {
      email: config.credentials.validUser.email,
      password: 'WrongPassword123!',
    };

    const response = await apiHelper.post(`${apiBaseUrl}/auth/login`, loginData);

    await apiHelper.validateStatusCode(response, 401);

    const body = await apiHelper.getResponseBody(response);
    expect(body).toHaveProperty('error');

    Logger.success('Invalid password returned 401 error');
  });

  test('API_TC004 - Login with Missing Email', async () => {
    Logger.info('API Test: Login with Missing Email');

    const loginData = {
      password: config.credentials.validUser.password,
    };

    const response = await apiHelper.post(`${apiBaseUrl}/auth/login`, loginData);

    await apiHelper.validateStatusCode(response, 400);

    Logger.success('Missing email returned 400 error');
  });

  test('API_TC005 - Login with Missing Password', async () => {
    Logger.info('API Test: Login with Missing Password');

    const loginData = {
      email: config.credentials.validUser.email,
    };

    const response = await apiHelper.post(`${apiBaseUrl}/auth/login`, loginData);

    await apiHelper.validateStatusCode(response, 400);

    Logger.success('Missing password returned 400 error');
  });

  test('API_TC006 - Register New User', async () => {
    Logger.info('API Test: Register New User');

    const userData = DataGenerator.generateUserData();
    const registerData = {
      firstName: userData.firstName,
      lastName: userData.lastName,
      email: userData.email,
      password: userData.password,
    };

    const response = await apiHelper.post(`${apiBaseUrl}/auth/register`, registerData);

    await apiHelper.validateStatusCode(response, 201);

    const body = await apiHelper.getResponseBody(response);
    expect(body).toHaveProperty('userId');
    expect(body).toHaveProperty('email', userData.email);

    Logger.success('User registered successfully via API');
  });

  test('API_TC007 - Register with Existing Email', async () => {
    Logger.info('API Test: Register with Existing Email');

    const registerData = {
      firstName: 'Test',
      lastName: 'User',
      email: config.credentials.validUser.email,
      password: 'Test@12345',
    };

    const response = await apiHelper.post(`${apiBaseUrl}/auth/register`, registerData);

    await apiHelper.validateStatusCode(response, 409);

    const body = await apiHelper.getResponseBody(response);
    expect(body).toHaveProperty('error');

    Logger.success('Duplicate email returned 409 conflict error');
  });

  test('API_TC008 - Verify Token Expiration', async ({ request }) => {
    Logger.info('API Test: Verify Token Expiration');

    const expiredToken = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.expired.token';

    const response = await request.get(`${apiBaseUrl}/user/profile`, {
      headers: {
        Authorization: `Bearer ${expiredToken}`,
      },
    });

    expect(response.status()).toBe(401);

    Logger.success('Expired token rejected correctly');
  });

  test('API_TC009 - Access Protected Resource Without Token', async ({ request }) => {
    Logger.info('API Test: Access Protected Resource Without Token');

    const response = await request.get(`${apiBaseUrl}/user/profile`);

    expect(response.status()).toBe(401);

    Logger.success('Unauthorized access blocked correctly');
  });

  test('API_TC010 - Logout and Invalidate Token', async () => {
    Logger.info('API Test: Logout and Invalidate Token');

    // First login to get token
    const loginData = {
      email: config.credentials.validUser.email,
      password: config.credentials.validUser.password,
    };

    const loginResponse = await apiHelper.post(`${apiBaseUrl}/auth/login`, loginData);
    const { token } = await apiHelper.getResponseBody(loginResponse);

    // Now logout
    const logoutResponse = await apiHelper.post(
      `${apiBaseUrl}/auth/logout`,
      {},
      {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      }
    );

    await apiHelper.validateStatusCode(logoutResponse, 200);

    Logger.success('Logout successful and token invalidated');
  });
});
