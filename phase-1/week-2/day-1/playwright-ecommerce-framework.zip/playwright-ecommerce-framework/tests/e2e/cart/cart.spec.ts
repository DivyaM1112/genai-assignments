import { test, expect } from '@playwright/test';
import { LoginPage } from '../../../src/pages/login.page';
import { ProductsPage } from '../../../src/pages/products.page';
import { CartPage } from '../../../src/pages/cart.page';
import { config } from '../../../src/config/environment.config';
import { Logger } from '../../../src/utils/logger';

test.describe('Shopping Cart Tests', () => {
  let loginPage: LoginPage;
  let productsPage: ProductsPage;
  let cartPage: CartPage;

  test.beforeEach(async ({ page }) => {
    loginPage = new LoginPage(page);
    productsPage = new ProductsPage(page);
    cartPage = new CartPage(page);

    // Login before each test
    await loginPage.navigateToLogin();
    await loginPage.login(
      config.credentials.validUser.email,
      config.credentials.validUser.password
    );
  });

  test('TC021 - View Empty Cart', async () => {
    Logger.info('Test: View Empty Cart');
    
    await cartPage.navigateToCart();
    
    const isEmpty = await cartPage.isCartEmpty();
    expect(isEmpty).toBeTruthy();
    
    Logger.success('Empty cart displayed correctly');
  });

  test('TC022 - Add Product and Verify in Cart', async () => {
    Logger.info('Test: Add Product and Verify in Cart');
    
    await productsPage.navigateToProducts();
    await productsPage.addProductToCartByIndex(0);
    
    await cartPage.navigateToCart();
    
    const itemCount = await cartPage.getCartItemCount();
    expect(itemCount).toBe(1);
    
    Logger.success('Product appears in cart successfully');
  });

  test('TC023 - Remove Product from Cart', async () => {
    Logger.info('Test: Remove Product from Cart');
    
    // Add product first
    await productsPage.navigateToProducts();
    await productsPage.addProductToCartByIndex(0);
    
    await cartPage.navigateToCart();
    
    const initialCount = await cartPage.getCartItemCount();
    expect(initialCount).toBe(1);
    
    await cartPage.removeItemByIndex(0);
    
    const isEmpty = await cartPage.isCartEmpty();
    expect(isEmpty).toBeTruthy();
    
    Logger.success('Product removed from cart successfully');
  });

  test('TC024 - Update Product Quantity in Cart', async () => {
    Logger.info('Test: Update Product Quantity in Cart');
    
    await productsPage.navigateToProducts();
    await productsPage.addProductToCartByIndex(0);
    
    await cartPage.navigateToCart();
    
    await cartPage.increaseQuantity(0);
    
    // Verify quantity increased (implementation depends on your app)
    const itemCount = await cartPage.getCartItemCount();
    expect(itemCount).toBeGreaterThanOrEqual(1);
    
    Logger.success('Product quantity updated successfully');
  });

  test('TC025 - Verify Cart Total Calculation', async () => {
    Logger.info('Test: Verify Cart Total Calculation');
    
    await productsPage.navigateToProducts();
    await productsPage.addProductToCartByIndex(0);
    
    await cartPage.navigateToCart();
    
    const subtotal = await cartPage.getSubtotal();
    const total = await cartPage.getTotal();
    
    expect(subtotal).toBeTruthy();
    expect(total).toBeTruthy();
    
    Logger.success('Cart totals displayed correctly');
  });

  test('TC026 - Apply Valid Promo Code', async () => {
    Logger.info('Test: Apply Valid Promo Code');
    
    await productsPage.navigateToProducts();
    await productsPage.addProductToCartByIndex(0);
    
    await cartPage.navigateToCart();
    
    await cartPage.applyPromoCode('SAVE10');
    
    // Verify discount is applied
    const discount = await cartPage.getDiscount();
    expect(discount).toBeTruthy();
    
    Logger.success('Promo code applied successfully');
  });

  test('TC027 - Apply Invalid Promo Code', async () => {
    Logger.info('Test: Apply Invalid Promo Code');
    
    await productsPage.navigateToProducts();
    await productsPage.addProductToCartByIndex(0);
    
    await cartPage.navigateToCart();
    
    await cartPage.applyPromoCode('INVALID123');
    
    // Should show error or no discount
    Logger.success('Invalid promo code handled correctly');
  });

  test('TC028 - Continue Shopping from Cart', async () => {
    Logger.info('Test: Continue Shopping from Cart');
    
    await productsPage.navigateToProducts();
    await productsPage.addProductToCartByIndex(0);
    
    await cartPage.navigateToCart();
    await cartPage.continueShopping();
    
    const currentUrl = await cartPage.getCurrentURL();
    expect(currentUrl).toContain('products');
    
    Logger.success('Navigated back to products successfully');
  });

  test('TC029 - Add Multiple Different Products to Cart', async () => {
    Logger.info('Test: Add Multiple Different Products to Cart');
    
    await productsPage.navigateToProducts();
    
    const productsToAdd = 3;
    for (let i = 0; i < productsToAdd; i++) {
      await productsPage.addProductToCartByIndex(i);
    }
    
    await cartPage.navigateToCart();
    
    const itemCount = await cartPage.getCartItemCount();
    expect(itemCount).toBe(productsToAdd);
    
    Logger.success(`${productsToAdd} different products in cart`);
  });

  test('TC030 - Clear Entire Cart', async () => {
    Logger.info('Test: Clear Entire Cart');
    
    await productsPage.navigateToProducts();
    await productsPage.addProductToCartByIndex(0);
    await productsPage.addProductToCartByIndex(1);
    
    await cartPage.navigateToCart();
    
    await cartPage.clearCart();
    
    const isEmpty = await cartPage.isCartEmpty();
    expect(isEmpty).toBeTruthy();
    
    Logger.success('Cart cleared successfully');
  });
});
