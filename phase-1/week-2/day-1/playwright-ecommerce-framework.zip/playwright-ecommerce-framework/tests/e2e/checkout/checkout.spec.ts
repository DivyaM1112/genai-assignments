import { test, expect } from '@playwright/test';
import { LoginPage } from '../../../src/pages/login.page';
import { ProductsPage } from '../../../src/pages/products.page';
import { CartPage } from '../../../src/pages/cart.page';
import { CheckoutPage } from '../../../src/pages/checkout.page';
import { config } from '../../../src/config/environment.config';
import { Logger } from '../../../src/utils/logger';
import { DataGenerator } from '../../../src/utils/data-generator';

test.describe('Checkout Tests', () => {
  let loginPage: LoginPage;
  let productsPage: ProductsPage;
  let cartPage: CartPage;
  let checkoutPage: CheckoutPage;

  test.beforeEach(async ({ page }) => {
    loginPage = new LoginPage(page);
    productsPage = new ProductsPage(page);
    cartPage = new CartPage(page);
    checkoutPage = new CheckoutPage(page);

    // Login and add product to cart before each test
    await loginPage.navigateToLogin();
    await loginPage.login(
      config.credentials.validUser.email,
      config.credentials.validUser.password
    );
    
    await productsPage.navigateToProducts();
    await productsPage.addProductToCartByIndex(0);
  });

  test('TC031 - Navigate to Checkout from Cart', async () => {
    Logger.info('Test: Navigate to Checkout from Cart');
    
    await cartPage.navigateToCart();
    await cartPage.proceedToCheckout();
    
    const currentUrl = await checkoutPage.getCurrentURL();
    expect(currentUrl).toContain('checkout');
    
    Logger.success('Navigated to checkout successfully');
  });

  test('TC032 - Complete Checkout with Valid Information', async () => {
    Logger.info('Test: Complete Checkout with Valid Information');
    
    await cartPage.navigateToCart();
    await cartPage.proceedToCheckout();
    
    const userData = DataGenerator.generateUserData();
    const addressData = DataGenerator.generateAddress();
    const cardData = DataGenerator.generateCreditCard();
    
    const shippingData = {
      firstName: userData.firstName,
      lastName: userData.lastName,
      email: userData.email,
      phone: userData.phone,
      address: addressData.street,
      city: addressData.city,
      state: addressData.state,
      zip: addressData.zip,
      country: addressData.country,
    };
    
    const paymentData = {
      cardNumber: cardData.number,
      expiryDate: cardData.expiry,
      cvv: cardData.cvv,
      cardHolderName: userData.fullName,
    };
    
    await checkoutPage.completeCheckout(shippingData, paymentData);
    
    const isConfirmed = await checkoutPage.isOrderConfirmed();
    expect(isConfirmed).toBeTruthy();
    
    const orderNumber = await checkoutPage.getOrderNumber();
    expect(orderNumber).toBeTruthy();
    
    Logger.success(`Order placed successfully. Order Number: ${orderNumber}`);
  });

  test('TC033 - Checkout with Missing Shipping Information', async () => {
    Logger.info('Test: Checkout with Missing Shipping Information');
    
    await cartPage.navigateToCart();
    await cartPage.proceedToCheckout();
    
    const shippingData = {
      firstName: '',
      lastName: '',
      email: '',
      phone: '',
      address: '',
      city: '',
      state: '',
      zip: '',
    };
    
    await checkoutPage.fillShippingInformation(shippingData);
    await checkoutPage.continueToPayment();
    
    // Should show validation errors
    const currentUrl = await checkoutPage.getCurrentURL();
    expect(currentUrl).toContain('checkout');
    
    Logger.success('Validation errors displayed for missing fields');
  });

  test('TC034 - Checkout with Invalid Email Format', async () => {
    Logger.info('Test: Checkout with Invalid Email Format');
    
    await cartPage.navigateToCart();
    await cartPage.proceedToCheckout();
    
    const userData = DataGenerator.generateUserData();
    const addressData = DataGenerator.generateAddress();
    
    const shippingData = {
      firstName: userData.firstName,
      lastName: userData.lastName,
      email: 'invalid-email-format',
      phone: userData.phone,
      address: addressData.street,
      city: addressData.city,
      state: addressData.state,
      zip: addressData.zip,
    };
    
    await checkoutPage.fillShippingInformation(shippingData);
    await checkoutPage.continueToPayment();
    
    // Should show email validation error
    Logger.success('Email validation working correctly');
  });

  test('TC035 - Checkout with Invalid Credit Card', async () => {
    Logger.info('Test: Checkout with Invalid Credit Card');
    
    await cartPage.navigateToCart();
    await cartPage.proceedToCheckout();
    
    const userData = DataGenerator.generateUserData();
    const addressData = DataGenerator.generateAddress();
    
    const shippingData = {
      firstName: userData.firstName,
      lastName: userData.lastName,
      email: userData.email,
      phone: userData.phone,
      address: addressData.street,
      city: addressData.city,
      state: addressData.state,
      zip: addressData.zip,
    };
    
    await checkoutPage.fillShippingInformation(shippingData);
    await checkoutPage.continueToPayment();
    
    const invalidPaymentData = {
      cardNumber: '1234567890123456',
      expiryDate: '01/20',
      cvv: '999',
      cardHolderName: userData.fullName,
    };
    
    await checkoutPage.fillPaymentInformation(invalidPaymentData);
    await checkoutPage.placeOrder();
    
    // Should show payment error
    Logger.success('Invalid credit card handled correctly');
  });

  test('TC036 - Verify Order Summary Before Checkout', async () => {
    Logger.info('Test: Verify Order Summary Before Checkout');
    
    await cartPage.navigateToCart();
    await cartPage.proceedToCheckout();
    
    const summaryTotal = await checkoutPage.getSummaryTotal();
    expect(summaryTotal).toBeTruthy();
    expect(summaryTotal).toMatch(/\$|€|£/);
    
    Logger.success('Order summary displayed correctly');
  });

  test('TC037 - Back to Cart from Checkout', async () => {
    Logger.info('Test: Back to Cart from Checkout');
    
    await cartPage.navigateToCart();
    await cartPage.proceedToCheckout();
    
    await checkoutPage.backToCart();
    
    const currentUrl = await checkoutPage.getCurrentURL();
    expect(currentUrl).toContain('cart');
    
    Logger.success('Navigated back to cart successfully');
  });

  test('TC038 - Checkout with Special Characters in Address', async () => {
    Logger.info('Test: Checkout with Special Characters in Address');
    
    await cartPage.navigateToCart();
    await cartPage.proceedToCheckout();
    
    const userData = DataGenerator.generateUserData();
    
    const shippingData = {
      firstName: userData.firstName,
      lastName: userData.lastName,
      email: userData.email,
      phone: userData.phone,
      address: "123 O'Brien St., Apt #5",
      city: "San José",
      state: 'CA',
      zip: '90210',
    };
    
    await checkoutPage.fillShippingInformation(shippingData);
    
    Logger.success('Special characters in address handled correctly');
  });

  test('TC039 - Checkout with Maximum Length Fields', async () => {
    Logger.info('Test: Checkout with Maximum Length Fields');
    
    await cartPage.navigateToCart();
    await cartPage.proceedToCheckout();
    
    const longString = DataGenerator.generateRandomString(100);
    
    const shippingData = {
      firstName: longString.substring(0, 50),
      lastName: longString.substring(0, 50),
      email: `test${DataGenerator.generateRandomString(40)}@example.com`,
      phone: DataGenerator.generateRandomPhone(),
      address: longString,
      city: longString.substring(0, 30),
      state: 'CA',
      zip: '90210',
    };
    
    await checkoutPage.fillShippingInformation(shippingData);
    
    Logger.success('Maximum length fields handled correctly');
  });

  test('TC040 - Complete End-to-End Purchase Flow', async () => {
    Logger.info('Test: Complete End-to-End Purchase Flow');
    
    // This test covers the entire flow from login to order confirmation
    await cartPage.navigateToCart();
    
    const cartTotal = await cartPage.getTotal();
    Logger.info(`Cart Total: ${cartTotal}`);
    
    await cartPage.proceedToCheckout();
    
    const userData = DataGenerator.generateUserData();
    const addressData = DataGenerator.generateAddress();
    const cardData = DataGenerator.generateCreditCard();
    
    const shippingData = {
      firstName: userData.firstName,
      lastName: userData.lastName,
      email: userData.email,
      phone: userData.phone,
      address: addressData.street,
      city: addressData.city,
      state: addressData.state,
      zip: addressData.zip,
      country: addressData.country,
    };
    
    const paymentData = {
      cardNumber: cardData.number,
      expiryDate: cardData.expiry,
      cvv: cardData.cvv,
      cardHolderName: userData.fullName,
    };
    
    await checkoutPage.completeCheckout(shippingData, paymentData);
    
    const isConfirmed = await checkoutPage.isOrderConfirmed();
    expect(isConfirmed).toBeTruthy();
    
    const confirmationMessage = await checkoutPage.getConfirmationMessage();
    expect(confirmationMessage).toBeTruthy();
    
    const orderNumber = await checkoutPage.getOrderNumber();
    expect(orderNumber).toBeTruthy();
    
    Logger.success(`End-to-End purchase completed. Order: ${orderNumber}`);
  });
});
