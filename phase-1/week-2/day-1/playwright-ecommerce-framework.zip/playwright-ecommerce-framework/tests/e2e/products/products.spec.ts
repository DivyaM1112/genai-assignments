import { test, expect } from '@playwright/test';
import { LoginPage } from '../../../src/pages/login.page';
import { ProductsPage } from '../../../src/pages/products.page';
import { config } from '../../../src/config/environment.config';
import { Logger } from '../../../src/utils/logger';

test.describe('Product Tests', () => {
  let loginPage: LoginPage;
  let productsPage: ProductsPage;

  test.beforeEach(async ({ page }) => {
    loginPage = new LoginPage(page);
    productsPage = new ProductsPage(page);

    // Login before each test
    await loginPage.navigateToLogin();
    await loginPage.login(
      config.credentials.validUser.email,
      config.credentials.validUser.password
    );
    
    await productsPage.navigateToProducts();
  });

  test('TC011 - Verify Products Page Loads Successfully', async () => {
    Logger.info('Test: Verify Products Page Loads Successfully');
    
    const productCount = await productsPage.getProductCount();
    expect(productCount).toBeGreaterThan(0);
    
    Logger.success(`Products page loaded with ${productCount} products`);
  });

  test('TC012 - Verify Product Names Are Displayed', async () => {
    Logger.info('Test: Verify Product Names Are Displayed');
    
    const productNames = await productsPage.getProductNames();
    expect(productNames.length).toBeGreaterThan(0);
    
    productNames.forEach(name => {
      expect(name).toBeTruthy();
      expect(name.length).toBeGreaterThan(0);
    });
    
    Logger.success('All product names are displayed correctly');
  });

  test('TC013 - Verify Product Prices Are Displayed', async () => {
    Logger.info('Test: Verify Product Prices Are Displayed');
    
    const productPrices = await productsPage.getProductPrices();
    expect(productPrices.length).toBeGreaterThan(0);
    
    productPrices.forEach(price => {
      expect(price).toBeTruthy();
      expect(price).toMatch(/\$|€|£/); // Contains currency symbol
    });
    
    Logger.success('All product prices are displayed correctly');
  });

  test('TC014 - Add Single Product to Cart', async () => {
    Logger.info('Test: Add Single Product to Cart');
    
    const initialCartCount = await productsPage.getCartCount();
    
    await productsPage.addProductToCartByIndex(0);
    
    const updatedCartCount = await productsPage.getCartCount();
    expect(updatedCartCount).toBe(initialCartCount + 1);
    
    Logger.success('Product added to cart successfully');
  });

  test('TC015 - Add Multiple Products to Cart', async () => {
    Logger.info('Test: Add Multiple Products to Cart');
    
    const initialCartCount = await productsPage.getCartCount();
    const productsToAdd = 3;
    
    for (let i = 0; i < productsToAdd; i++) {
      await productsPage.addProductToCartByIndex(i);
    }
    
    const updatedCartCount = await productsPage.getCartCount();
    expect(updatedCartCount).toBe(initialCartCount + productsToAdd);
    
    Logger.success(`${productsToAdd} products added to cart successfully`);
  });

  test('TC016 - Search for Existing Product', async () => {
    Logger.info('Test: Search for Existing Product');
    
    const productNames = await productsPage.getProductNames();
    const searchTerm = productNames[0].split(' ')[0]; // Get first word of first product
    
    await productsPage.searchProduct(searchTerm);
    
    const searchResults = await productsPage.getProductNames();
    expect(searchResults.length).toBeGreaterThan(0);
    
    Logger.success('Search returned results successfully');
  });

  test('TC017 - Search for Non-Existing Product', async () => {
    Logger.info('Test: Search for Non-Existing Product');
    
    await productsPage.searchProduct('XYZ123NonExistentProduct999');
    
    const noResults = await productsPage.isNoResultsDisplayed();
    expect(noResults).toBeTruthy();
    
    Logger.success('No results message displayed correctly');
  });

  test('TC018 - Filter Products by Category', async () => {
    Logger.info('Test: Filter Products by Category');
    
    const initialCount = await productsPage.getProductCount();
    
    await productsPage.filterByCategory('Electronics');
    
    const filteredCount = await productsPage.getProductCount();
    expect(filteredCount).toBeLessThanOrEqual(initialCount);
    
    Logger.success('Products filtered successfully');
  });

  test('TC019 - Sort Products by Price Low to High', async () => {
    Logger.info('Test: Sort Products by Price Low to High');
    
    await productsPage.sortProducts('price-low-high');
    
    const prices = await productsPage.getProductPrices();
    
    // Verify sorting (basic check)
    expect(prices.length).toBeGreaterThan(0);
    
    Logger.success('Products sorted by price low to high');
  });

  test('TC020 - Sort Products by Price High to Low', async () => {
    Logger.info('Test: Sort Products by Price High to Low');
    
    await productsPage.sortProducts('price-high-low');
    
    const prices = await productsPage.getProductPrices();
    expect(prices.length).toBeGreaterThan(0);
    
    Logger.success('Products sorted by price high to low');
  });
});
