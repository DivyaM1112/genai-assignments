import { test, expect } from '@playwright/test';
import { LoginPage } from '../../../src/pages/login.page';
import { config } from '../../../src/config/environment.config';
import { Logger } from '../../../src/utils/logger';
import { DataGenerator } from '../../../src/utils/data-generator';

test.describe('Authentication Tests', () => {
  let loginPage: LoginPage;

  test.beforeEach(async ({ page }) => {
    loginPage = new LoginPage(page);
    await loginPage.navigateToLogin();
  });

  test('TC001 - Valid Login with Correct Credentials', async () => {
    Logger.info('Test: Valid Login with Correct Credentials');
    
    await loginPage.login(
      config.credentials.validUser.email,
      config.credentials.validUser.password
    );

    // Verify successful login
    const isLoggedIn = await loginPage.isLoggedIn();
    expect(isLoggedIn).toBeTruthy();
    
    Logger.success('User logged in successfully');
  });

  test('TC002 - Invalid Login with Incorrect Email', async () => {
    Logger.info('Test: Invalid Login with Incorrect Email');
    
    const invalidEmail = DataGenerator.generateRandomEmail();
    
    await loginPage.login(
      invalidEmail,
      config.credentials.validUser.password
    );

    // Verify error message is displayed
    const isErrorDisplayed = await loginPage.isErrorMessageDisplayed();
    expect(isErrorDisplayed).toBeTruthy();
    
    const errorMessage = await loginPage.getErrorMessage();
    expect(errorMessage.toLowerCase()).toContain('invalid');
    
    Logger.success('Error message displayed correctly for invalid email');
  });

  test('TC003 - Invalid Login with Incorrect Password', async () => {
    Logger.info('Test: Invalid Login with Incorrect Password');
    
    await loginPage.login(
      config.credentials.validUser.email,
      'WrongPassword123!'
    );

    // Verify error message is displayed
    const isErrorDisplayed = await loginPage.isErrorMessageDisplayed();
    expect(isErrorDisplayed).toBeTruthy();
    
    const errorMessage = await loginPage.getErrorMessage();
    expect(errorMessage.toLowerCase()).toContain('invalid');
    
    Logger.success('Error message displayed correctly for invalid password');
  });

  test('TC004 - Login with Empty Email Field', async () => {
    Logger.info('Test: Login with Empty Email Field');
    
    await loginPage.login(
      '',
      config.credentials.validUser.password
    );

    // Verify validation or error
    const isErrorDisplayed = await loginPage.isErrorMessageDisplayed();
    expect(isErrorDisplayed).toBeTruthy();
    
    Logger.success('Validation working for empty email field');
  });

  test('TC005 - Login with Empty Password Field', async () => {
    Logger.info('Test: Login with Empty Password Field');
    
    await loginPage.login(
      config.credentials.validUser.email,
      ''
    );

    // Verify validation or error
    const isErrorDisplayed = await loginPage.isErrorMessageDisplayed();
    expect(isErrorDisplayed).toBeTruthy();
    
    Logger.success('Validation working for empty password field');
  });

  test('TC006 - Login with Both Fields Empty', async () => {
    Logger.info('Test: Login with Both Fields Empty');
    
    await loginPage.login('', '');

    // Verify validation or error
    const isErrorDisplayed = await loginPage.isErrorMessageDisplayed();
    expect(isErrorDisplayed).toBeTruthy();
    
    Logger.success('Validation working for all empty fields');
  });

  test('TC007 - Login with Special Characters in Email', async () => {
    Logger.info('Test: Login with Special Characters in Email');
    
    await loginPage.login(
      'test!#$%@example.com',
      config.credentials.validUser.password
    );

    const isErrorDisplayed = await loginPage.isErrorMessageDisplayed();
    expect(isErrorDisplayed).toBeTruthy();
    
    Logger.success('Special characters handled correctly');
  });

  test('TC008 - Login with SQL Injection Attempt', async () => {
    Logger.info('Test: Login with SQL Injection Attempt');
    
    await loginPage.login(
      "admin' OR '1'='1",
      "password' OR '1'='1"
    );

    // Should not login successfully
    const isLoggedIn = await loginPage.isLoggedIn();
    expect(isLoggedIn).toBeFalsy();
    
    Logger.success('SQL injection attempt blocked successfully');
  });

  test('TC009 - Remember Me Functionality', async () => {
    Logger.info('Test: Remember Me Functionality');
    
    await loginPage.loginWithRememberMe(
      config.credentials.validUser.email,
      config.credentials.validUser.password
    );

    const isLoggedIn = await loginPage.isLoggedIn();
    expect(isLoggedIn).toBeTruthy();
    
    Logger.success('Remember Me functionality works');
  });

  test('TC010 - Logout Functionality', async () => {
    Logger.info('Test: Logout Functionality');
    
    // Login first
    await loginPage.login(
      config.credentials.validUser.email,
      config.credentials.validUser.password
    );

    expect(await loginPage.isLoggedIn()).toBeTruthy();

    // Logout
    await loginPage.logout();

    // Verify user is logged out
    const isLoggedIn = await loginPage.isLoggedIn();
    expect(isLoggedIn).toBeFalsy();
    
    Logger.success('User logged out successfully');
  });
});
