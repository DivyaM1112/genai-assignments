# Playwright E-Commerce Test Automation Framework

A comprehensive Playwright TypeScript framework for UI and API testing of e-commerce applications, built with industry best practices and a hybrid Page Object Model (POM) architecture.

---

## 📋 Table of Contents

- [Features](#features)
- [Project Structure](#project-structure)
- [Prerequisites](#prerequisites)
- [Installation](#installation)
- [Configuration](#configuration)
- [Running Tests](#running-tests)
- [Test Cases Coverage](#test-cases-coverage)
- [Reporting](#reporting)
- [Best Practices](#best-practices)
- [CI/CD Integration](#cicd-integration)
- [Troubleshooting](#troubleshooting)

---

## ✨ Features

- **Hybrid Architecture**: Page Object Model (POM) + Helper Utilities for maximum maintainability
- **TypeScript**: Full type safety and IntelliSense support
- **Multi-Environment Support**: Dev, Staging, and Production configurations
- **Comprehensive Test Coverage**: 40+ test cases covering Authentication, Products, Cart, and Checkout
- **API & UI Testing**: Complete test coverage for both UI and API layers
- **Multiple Reporters**: HTML, JSON, JUnit, and List reporters
- **Custom Logger**: Built-in console logging with color-coded output
- **Data Generation**: Utilities for generating realistic test data
- **Screenshot & Video**: Automatic capture on test failures
- **Parallel Execution**: Run tests in parallel for faster execution
- **Cross-Browser Testing**: Support for Chromium, Firefox, and WebKit
- **Mobile Testing**: Support for mobile viewports (Chrome & Safari)

---

## 📁 Project Structure

```
playwright-ecommerce-framework/
├── src/
│   ├── config/
│   │   └── environment.config.ts      # Environment configurations (dev, staging, prod)
│   ├── pages/
│   │   ├── base.page.ts               # Base page with common methods
│   │   ├── login.page.ts              # Login page object
│   │   ├── products.page.ts           # Products page object
│   │   ├── cart.page.ts               # Cart page object
│   │   └── checkout.page.ts           # Checkout page object
│   ├── helpers/
│   │   ├── api.helper.ts              # API request helper
│   │   └── wait.helper.ts             # Wait and synchronization helper
│   ├── utils/
│   │   ├── logger.ts                  # Custom logging utility
│   │   └── data-generator.ts          # Test data generation utility
│   └── types/
│       └── (custom type definitions)
├── tests/
│   ├── e2e/
│   │   ├── auth/
│   │   │   └── login.spec.ts          # Authentication tests (TC001-TC010)
│   │   ├── products/
│   │   │   └── products.spec.ts       # Product tests (TC011-TC020)
│   │   ├── cart/
│   │   │   └── cart.spec.ts           # Cart tests (TC021-TC030)
│   │   └── checkout/
│   │       └── checkout.spec.ts       # Checkout tests (TC031-TC040)
│   └── api/
│       ├── auth.api.spec.ts           # API Auth tests (API_TC001-API_TC010)
│       ├── products.api.spec.ts       # API Products tests (API_TC011-API_TC020)
│       └── cart.api.spec.ts           # API Cart tests (API_TC021-API_TC030)
├── playwright-report/                  # HTML test reports
├── test-results/                       # Test results and artifacts
├── playwright.config.ts                # Playwright configuration
├── tsconfig.json                       # TypeScript configuration
├── package.json                        # Dependencies and scripts
├── .env.example                        # Environment variables template
└── README.md                           # This file
```

---

## 🔧 Prerequisites

Before running this framework, ensure you have the following installed:

- **Node.js**: v18.x or higher
- **npm**: v8.x or higher (comes with Node.js)
- **Git**: For version control

---

## 📦 Installation

### Step 1: Extract the Framework

Extract the downloaded ZIP file to your desired location.

### Step 2: Navigate to Project Directory

```bash
cd playwright-ecommerce-framework
```

### Step 3: Install Dependencies

```bash
npm install
```

### Step 4: Install Playwright Browsers

```bash
npm run install:browsers
```

or

```bash
npx playwright install
```

---

## ⚙️ Configuration

### Environment Configuration

The framework supports multiple environments (dev, staging, prod).

1. **Copy the environment template**:
   ```bash
   cp .env.example .env
   ```

2. **Update `.env` with your values**:
   ```env
   ENV=dev
   BASE_URL=https://your-app-url.com
   API_URL=https://your-api-url.com
   VALID_USER_EMAIL=your-test-email@example.com
   VALID_USER_PASSWORD=your-test-password
   ```

3. **Environment-specific configurations** are located in:
   - `src/config/environment.config.ts`

### Playwright Configuration

Modify `playwright.config.ts` to customize:
- Base URL
- Timeouts
- Retry logic
- Browser configurations
- Reporter settings
- Screenshot/Video options

---

## 🚀 Running Tests

### Run All Tests

```bash
npm test
```

### Run Tests in UI Mode (Interactive)

```bash
npm run test:ui
```

### Run Tests in Headed Mode (See Browser)

```bash
npm run test:headed
```

### Run Tests in Debug Mode

```bash
npm run test:debug
```

### Run Specific Browser Tests

```bash
# Chromium only
npm run test:chrome

# Firefox only
npm run test:firefox

# WebKit only
npm run test:webkit
```

### Run Specific Test Suites

```bash
# Run only authentication tests
npm run test:auth

# Run only API tests
npm run test:api

# Run only E2E tests
npm run test:e2e
```

### Run Tests for Specific Environment

```bash
# Development environment
npm run test:dev

# Staging environment
npm run test:staging

# Production environment
npm run test:prod
```

### Run Specific Test File

```bash
npx playwright test tests/e2e/auth/login.spec.ts
```

### Run Specific Test Case

```bash
npx playwright test -g "TC001"
```

### Run Tests with Tags

```bash
npx playwright test --grep @smoke
```

---

## 📊 Test Cases Coverage

### UI Test Cases (40 Tests)

#### Authentication Tests (TC001-TC010)
- ✅ TC001: Valid Login with Correct Credentials
- ✅ TC002: Invalid Login with Incorrect Email
- ✅ TC003: Invalid Login with Incorrect Password
- ✅ TC004: Login with Empty Email Field
- ✅ TC005: Login with Empty Password Field
- ✅ TC006: Login with Both Fields Empty
- ✅ TC007: Login with Special Characters in Email
- ✅ TC008: Login with SQL Injection Attempt
- ✅ TC009: Remember Me Functionality
- ✅ TC010: Logout Functionality

#### Product Tests (TC011-TC020)
- ✅ TC011: Verify Products Page Loads Successfully
- ✅ TC012: Verify Product Names Are Displayed
- ✅ TC013: Verify Product Prices Are Displayed
- ✅ TC014: Add Single Product to Cart
- ✅ TC015: Add Multiple Products to Cart
- ✅ TC016: Search for Existing Product
- ✅ TC017: Search for Non-Existing Product
- ✅ TC018: Filter Products by Category
- ✅ TC019: Sort Products by Price Low to High
- ✅ TC020: Sort Products by Price High to Low

#### Shopping Cart Tests (TC021-TC030)
- ✅ TC021: View Empty Cart
- ✅ TC022: Add Product and Verify in Cart
- ✅ TC023: Remove Product from Cart
- ✅ TC024: Update Product Quantity in Cart
- ✅ TC025: Verify Cart Total Calculation
- ✅ TC026: Apply Valid Promo Code
- ✅ TC027: Apply Invalid Promo Code
- ✅ TC028: Continue Shopping from Cart
- ✅ TC029: Add Multiple Different Products to Cart
- ✅ TC030: Clear Entire Cart

#### Checkout Tests (TC031-TC040)
- ✅ TC031: Navigate to Checkout from Cart
- ✅ TC032: Complete Checkout with Valid Information
- ✅ TC033: Checkout with Missing Shipping Information
- ✅ TC034: Checkout with Invalid Email Format
- ✅ TC035: Checkout with Invalid Credit Card
- ✅ TC036: Verify Order Summary Before Checkout
- ✅ TC037: Back to Cart from Checkout
- ✅ TC038: Checkout with Special Characters in Address
- ✅ TC039: Checkout with Maximum Length Fields
- ✅ TC040: Complete End-to-End Purchase Flow

### API Test Cases (30 Tests)

#### API Authentication Tests (API_TC001-API_TC010)
- ✅ API_TC001: Login with Valid Credentials
- ✅ API_TC002: Login with Invalid Email
- ✅ API_TC003: Login with Invalid Password
- ✅ API_TC004: Login with Missing Email
- ✅ API_TC005: Login with Missing Password
- ✅ API_TC006: Register New User
- ✅ API_TC007: Register with Existing Email
- ✅ API_TC008: Verify Token Expiration
- ✅ API_TC009: Access Protected Resource Without Token
- ✅ API_TC010: Logout and Invalidate Token

#### API Products Tests (API_TC011-API_TC020)
- ✅ API_TC011: Get All Products
- ✅ API_TC012: Get Product by ID
- ✅ API_TC013: Get Non-Existent Product
- ✅ API_TC014: Search Products by Name
- ✅ API_TC015: Filter Products by Category
- ✅ API_TC016: Sort Products by Price
- ✅ API_TC017: Get Products with Pagination
- ✅ API_TC018: Verify Product Schema
- ✅ API_TC019: Create Product (Admin)
- ✅ API_TC020: Update Product (Admin)

#### API Cart Tests (API_TC021-API_TC030)
- ✅ API_TC021: Get Empty Cart
- ✅ API_TC022: Add Item to Cart
- ✅ API_TC023: Add Multiple Items to Cart
- ✅ API_TC024: Update Cart Item Quantity
- ✅ API_TC025: Remove Item from Cart
- ✅ API_TC026: Clear Entire Cart
- ✅ API_TC027: Get Cart Total
- ✅ API_TC028: Add Item with Invalid Product ID
- ✅ API_TC029: Add Item with Zero Quantity
- ✅ API_TC030: Add Item with Negative Quantity

---

## 📈 Reporting

### View HTML Report

After running tests, view the HTML report:

```bash
npm run report
```

or

```bash
npx playwright show-report
```

### Report Locations

- **HTML Report**: `playwright-report/index.html`
- **JSON Report**: `test-results/results.json`
- **JUnit Report**: `test-results/junit.xml`

### Report Features

- ✅ Detailed test execution summary
- ✅ Screenshots on failures
- ✅ Videos for failed tests
- ✅ Execution traces
- ✅ Step-by-step logs
- ✅ Time taken per test
- ✅ Filterable results

---

## 🎯 Best Practices

### Code Organization
- ✅ Separate concerns: Pages, Helpers, Utils, and Tests
- ✅ Single Responsibility Principle for each class
- ✅ Reusable helper functions
- ✅ Type-safe code with TypeScript

### Test Writing
- ✅ Use descriptive test names (TC001, TC002, etc.)
- ✅ Follow Arrange-Act-Assert pattern
- ✅ Independent tests (no test dependencies)
- ✅ Use data generators for dynamic data
- ✅ Clean up test data after execution

### Page Objects
- ✅ One page object per page/component
- ✅ Locators defined at the top
- ✅ Methods represent user actions
- ✅ No assertions in page objects
- ✅ Return values for verification

### Logging
- ✅ Use Logger utility for consistent logging
- ✅ Log important steps and actions
- ✅ Color-coded log levels (INFO, ERROR, SUCCESS, etc.)
- ✅ Structured log messages

### Wait Strategies
- ✅ Use explicit waits over implicit waits
- ✅ Wait for specific conditions
- ✅ Use WaitHelper for common wait scenarios
- ✅ Avoid hard-coded waits (sleep)

---

## 🔄 CI/CD Integration

### GitHub Actions Example

Create `.github/workflows/playwright.yml`:

```yaml
name: Playwright Tests

on:
  push:
    branches: [ main, develop ]
  pull_request:
    branches: [ main ]

jobs:
  test:
    timeout-minutes: 60
    runs-on: ubuntu-latest
    steps:
    - uses: actions/checkout@v3
    
    - uses: actions/setup-node@v3
      with:
        node-version: 18
        
    - name: Install dependencies
      run: npm ci
      
    - name: Install Playwright Browsers
      run: npx playwright install --with-deps
      
    - name: Run Playwright tests
      run: npm test
      env:
        ENV: staging
        
    - uses: actions/upload-artifact@v3
      if: always()
      with:
        name: playwright-report
        path: playwright-report/
        retention-days: 30
```

### Jenkins Example

```groovy
pipeline {
    agent any
    
    stages {
        stage('Install Dependencies') {
            steps {
                sh 'npm ci'
                sh 'npx playwright install --with-deps'
            }
        }
        
        stage('Run Tests') {
            steps {
                sh 'npm test'
            }
        }
        
        stage('Publish Reports') {
            steps {
                publishHTML([
                    reportDir: 'playwright-report',
                    reportFiles: 'index.html',
                    reportName: 'Playwright Test Report'
                ])
            }
        }
    }
}
```

---

## 🐛 Troubleshooting

### Common Issues and Solutions

#### Issue: Browsers not installed
```bash
# Solution: Install browsers
npx playwright install
```

#### Issue: Test timeout
```bash
# Solution: Increase timeout in playwright.config.ts
timeout: 90000  // Increase from 60000
```

#### Issue: Element not found
```bash
# Solution: Check locators and add explicit waits
await page.waitForSelector('your-selector');
```

#### Issue: Environment variables not loading
```bash
# Solution: Ensure .env file exists and is properly formatted
# Check environment.config.ts for correct variable names
```

#### Issue: API tests failing
```bash
# Solution: Verify API URLs in environment.config.ts
# Check network connectivity
# Ensure authentication tokens are valid
```

#### Issue: Tests running slowly
```bash
# Solution: Enable parallel execution
# Reduce number of workers if system is constrained
# Optimize wait strategies
```

---

## 📚 Additional Resources

- [Playwright Documentation](https://playwright.dev/)
- [TypeScript Documentation](https://www.typescriptlang.org/)
- [Node.js Documentation](https://nodejs.org/)

---

## 🤝 Contributing

1. Fork the repository
2. Create a feature branch (`git checkout -b feature/amazing-feature`)
3. Commit your changes (`git commit -m 'Add some amazing feature'`)
4. Push to the branch (`git push origin feature/amazing-feature`)
5. Open a Pull Request

---

## 📝 License

This project is licensed under the MIT License.

---

## 👤 Author

**Senior Test Engineer**

---

## 🎉 Happy Testing!

For any questions or issues, please create an issue in the repository or contact the test automation team.

---

**Last Updated**: December 2024
**Framework Version**: 1.0.0
**Playwright Version**: 1.42.0
