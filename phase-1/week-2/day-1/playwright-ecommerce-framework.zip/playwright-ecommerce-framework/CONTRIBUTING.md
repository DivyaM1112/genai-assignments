# Contributing Guidelines

Thank you for considering contributing to the Playwright E-Commerce Test Automation Framework!

## How to Contribute

### Reporting Bugs

If you find a bug, please create an issue with:
- Clear description of the bug
- Steps to reproduce
- Expected vs actual behavior
- Screenshots/logs if applicable
- Environment details (OS, Node version, etc.)

### Suggesting Enhancements

For feature requests:
- Clear description of the feature
- Use cases and benefits
- Proposed implementation (optional)

### Code Contributions

1. **Fork the repository**
2. **Create a feature branch**
   ```bash
   git checkout -b feature/your-feature-name
   ```

3. **Make your changes**
   - Follow the coding standards
   - Write/update tests
   - Update documentation

4. **Run tests**
   ```bash
   npm test
   ```

5. **Commit your changes**
   ```bash
   git commit -m "Add: Brief description of your changes"
   ```

6. **Push to your fork**
   ```bash
   git push origin feature/your-feature-name
   ```

7. **Create a Pull Request**

## Coding Standards

### TypeScript

- Use TypeScript for all new files
- Define proper types and interfaces
- Avoid `any` type when possible
- Use meaningful variable names

### Page Objects

- One page object per page/component
- Locators at the top of the class
- Methods represent user actions
- No assertions in page objects
- Return values for verification in tests

### Test Cases

- Descriptive test names with test case IDs
- Follow Arrange-Act-Assert pattern
- Independent tests (no dependencies)
- Clean up test data
- Use Logger for important steps

### Helpers and Utils

- Single responsibility
- Reusable functions
- Proper error handling
- Type-safe parameters

## File Structure

```
src/
├── pages/          → Page Objects
├── helpers/        → Helper utilities
├── utils/          → Common utilities
├── config/         → Configurations
├── fixtures/       → Test data
└── types/          → Type definitions

tests/
├── e2e/            → UI tests
└── api/            → API tests
```

## Naming Conventions

### Files
- Page Objects: `*.page.ts` (e.g., `login.page.ts`)
- Tests: `*.spec.ts` (e.g., `login.spec.ts`)
- Helpers: `*.helper.ts` (e.g., `api.helper.ts`)
- Utils: Descriptive names (e.g., `logger.ts`, `data-generator.ts`)

### Classes
- PascalCase (e.g., `LoginPage`, `ApiHelper`)

### Methods
- camelCase (e.g., `navigateToLogin`, `addToCart`)

### Constants
- UPPER_SNAKE_CASE (e.g., `MAX_TIMEOUT`, `API_BASE_URL`)

### Test Cases
- Test IDs: `TC001`, `TC002`, etc. for UI tests
- Test IDs: `API_TC001`, `API_TC002`, etc. for API tests

## Testing Your Changes

### Run All Tests
```bash
npm test
```

### Run Specific Tests
```bash
npx playwright test path/to/your/test.spec.ts
```

### Run in UI Mode
```bash
npm run test:ui
```

## Documentation

- Update README.md for major changes
- Add comments for complex logic
- Update type definitions
- Document new helper functions

## Pull Request Guidelines

### PR Title Format
```
Type: Brief description

Types:
- Add: New feature or test
- Fix: Bug fix
- Update: Updates to existing code
- Refactor: Code refactoring
- Docs: Documentation changes
- Chore: Maintenance tasks
```

### PR Description
Include:
- What changes were made
- Why the changes were needed
- How to test the changes
- Related issues (if any)

### PR Checklist
- [ ] Code follows project standards
- [ ] Tests added/updated
- [ ] All tests passing
- [ ] Documentation updated
- [ ] No breaking changes (or documented)

## Code Review Process

1. PR submitted
2. Automated tests run
3. Code review by maintainers
4. Address feedback
5. Approval and merge

## Questions?

If you have questions:
- Check existing documentation
- Look at existing code examples
- Create an issue for discussion

Thank you for contributing! 🎉
