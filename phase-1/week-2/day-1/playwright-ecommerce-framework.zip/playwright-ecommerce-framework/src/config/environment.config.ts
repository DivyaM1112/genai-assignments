export interface EnvironmentConfig {
  baseUrl: string;
  apiUrl: string;
  environment: string;
  timeout: number;
  credentials: {
    validUser: {
      email: string;
      password: string;
    };
    adminUser: {
      email: string;
      password: string;
    };
  };
}

const environments: Record<string, EnvironmentConfig> = {
  dev: {
    baseUrl: 'https://dev.example-ecommerce.com',
    apiUrl: 'https://api-dev.example-ecommerce.com',
    environment: 'dev',
    timeout: 30000,
    credentials: {
      validUser: {
        email: 'testuser@example.com',
        password: 'Test@123',
      },
      adminUser: {
        email: 'admin@example.com',
        password: 'Admin@123',
      },
    },
  },
  staging: {
    baseUrl: 'https://staging.example-ecommerce.com',
    apiUrl: 'https://api-staging.example-ecommerce.com',
    environment: 'staging',
    timeout: 30000,
    credentials: {
      validUser: {
        email: 'testuser@example.com',
        password: 'Test@123',
      },
      adminUser: {
        email: 'admin@example.com',
        password: 'Admin@123',
      },
    },
  },
  prod: {
    baseUrl: 'https://www.example-ecommerce.com',
    apiUrl: 'https://api.example-ecommerce.com',
    environment: 'prod',
    timeout: 30000,
    credentials: {
      validUser: {
        email: 'testuser@example.com',
        password: 'Test@123',
      },
      adminUser: {
        email: 'admin@example.com',
        password: 'Admin@123',
      },
    },
  },
};

const currentEnv = process.env.ENV || 'dev';
export const config: EnvironmentConfig = environments[currentEnv];
