import { Page, Locator } from '@playwright/test';
import { BasePage } from './base.page';
import { Logger } from '../utils/logger';

export class ProductsPage extends BasePage {
  // Locators
  private readonly productCards: Locator;
  private readonly addToCartButtons: Locator;
  private readonly productTitles: Locator;
  private readonly productPrices: Locator;
  private readonly searchInput: Locator;
  private readonly searchButton: Locator;
  private readonly sortDropdown: Locator;
  private readonly filterCategory: Locator;
  private readonly cartIcon: Locator;
  private readonly cartCount: Locator;
  private readonly noResultsMessage: Locator;

  constructor(page: Page) {
    super(page);
    
    this.productCards = page.locator('.product-card, [data-testid="product-item"]');
    this.addToCartButtons = page.locator('button:has-text("Add to Cart"), [data-testid="add-to-cart"]');
    this.productTitles = page.locator('.product-title, .product-name, h3');
    this.productPrices = page.locator('.product-price, .price');
    this.searchInput = page.locator('#search, [name="search"], [placeholder*="Search"]').first();
    this.searchButton = page.locator('button:has-text("Search"), [type="submit"]').first();
    this.sortDropdown = page.locator('#sort, select[name="sort"]').first();
    this.filterCategory = page.locator('.filter-category, .category-filter');
    this.cartIcon = page.locator('.cart-icon, [data-testid="cart-icon"]').first();
    this.cartCount = page.locator('.cart-count, .badge').first();
    this.noResultsMessage = page.locator('.no-results, .empty-state').first();
  }

  async navigateToProducts(): Promise<void> {
    Logger.step('Navigating to Products Page');
    await this.navigate('/products');
  }

  async getProductCount(): Promise<number> {
    Logger.debug('Getting product count');
    return await this.productCards.count();
  }

  async addProductToCart(productName: string): Promise<void> {
    Logger.step(`Adding product to cart: ${productName}`);
    const product = this.page.locator(`.product-card:has-text("${productName}")`).first();
    const addButton = product.locator('button:has-text("Add to Cart")').first();
    await this.click(addButton);
    await this.waitHelper.sleep(1000); // Wait for cart update animation
  }

  async addProductToCartByIndex(index: number): Promise<void> {
    Logger.step(`Adding product at index ${index} to cart`);
    const addButton = this.addToCartButtons.nth(index);
    await this.click(addButton);
    await this.waitHelper.sleep(1000);
  }

  async searchProduct(searchTerm: string): Promise<void> {
    Logger.step(`Searching for product: ${searchTerm}`);
    await this.fill(this.searchInput, searchTerm);
    await this.click(this.searchButton);
    await this.waitHelper.waitForPageLoad();
  }

  async getProductNames(): Promise<string[]> {
    Logger.debug('Getting all product names');
    const count = await this.productTitles.count();
    const names: string[] = [];
    
    for (let i = 0; i < count; i++) {
      const name = await this.productTitles.nth(i).textContent();
      if (name) names.push(name.trim());
    }
    
    return names;
  }

  async getProductPrices(): Promise<string[]> {
    Logger.debug('Getting all product prices');
    const count = await this.productPrices.count();
    const prices: string[] = [];
    
    for (let i = 0; i < count; i++) {
      const price = await this.productPrices.nth(i).textContent();
      if (price) prices.push(price.trim());
    }
    
    return prices;
  }

  async sortProducts(sortOption: string): Promise<void> {
    Logger.step(`Sorting products by: ${sortOption}`);
    await this.selectDropdown(this.sortDropdown, sortOption);
    await this.waitHelper.waitForPageLoad();
  }

  async filterByCategory(category: string): Promise<void> {
    Logger.step(`Filtering by category: ${category}`);
    const categoryFilter = this.page.locator(`.category-filter:has-text("${category}")`).first();
    await this.click(categoryFilter);
    await this.waitHelper.waitForPageLoad();
  }

  async getCartCount(): Promise<number> {
    Logger.debug('Getting cart count');
    const countText = await this.getText(this.cartCount);
    return parseInt(countText) || 0;
  }

  async goToCart(): Promise<void> {
    Logger.step('Navigating to cart');
    await this.click(this.cartIcon);
    await this.waitHelper.waitForPageLoad();
  }

  async isNoResultsDisplayed(): Promise<boolean> {
    return await this.isVisible(this.noResultsMessage);
  }

  async getProductDetails(productName: string): Promise<{ name: string; price: string }> {
    Logger.step(`Getting details for product: ${productName}`);
    const product = this.page.locator(`.product-card:has-text("${productName}")`).first();
    const name = await product.locator('.product-title, .product-name').textContent();
    const price = await product.locator('.product-price, .price').textContent();
    
    return {
      name: name?.trim() || '',
      price: price?.trim() || '',
    };
  }
}
