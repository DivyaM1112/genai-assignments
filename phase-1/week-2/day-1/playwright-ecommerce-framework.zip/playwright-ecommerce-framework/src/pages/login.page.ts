import { Page, Locator } from '@playwright/test';
import { BasePage } from './base.page';
import { Logger } from '../utils/logger';

export class LoginPage extends BasePage {
  // Locators
  private readonly emailInput: Locator;
  private readonly passwordInput: Locator;
  private readonly loginButton: Locator;
  private readonly errorMessage: Locator;
  private readonly forgotPasswordLink: Locator;
  private readonly signupLink: Locator;
  private readonly rememberMeCheckbox: Locator;
  private readonly logoutButton: Locator;
  private readonly userProfileIcon: Locator;

  constructor(page: Page) {
    super(page);
    
    // Initialize locators
    this.emailInput = page.locator('#email, [name="email"], [type="email"]').first();
    this.passwordInput = page.locator('#password, [name="password"], [type="password"]').first();
    this.loginButton = page.locator('button:has-text("Login"), button:has-text("Sign In"), [type="submit"]').first();
    this.errorMessage = page.locator('.error-message, .alert-danger, [role="alert"]').first();
    this.forgotPasswordLink = page.locator('a:has-text("Forgot Password")').first();
    this.signupLink = page.locator('a:has-text("Sign Up"), a:has-text("Register")').first();
    this.rememberMeCheckbox = page.locator('[type="checkbox"]').first();
    this.logoutButton = page.locator('button:has-text("Logout"), a:has-text("Logout")').first();
    this.userProfileIcon = page.locator('.user-profile, .user-icon, [data-testid="user-menu"]').first();
  }

  async navigateToLogin(): Promise<void> {
    Logger.step('Navigating to Login Page');
    await this.navigate('/login');
  }

  async login(email: string, password: string): Promise<void> {
    Logger.step(`Logging in with email: ${email}`);
    await this.fill(this.emailInput, email);
    await this.fill(this.passwordInput, password);
    await this.click(this.loginButton);
    await this.waitHelper.waitForPageLoad();
  }

  async loginWithRememberMe(email: string, password: string): Promise<void> {
    Logger.step(`Logging in with Remember Me enabled`);
    await this.fill(this.emailInput, email);
    await this.fill(this.passwordInput, password);
    await this.click(this.rememberMeCheckbox);
    await this.click(this.loginButton);
    await this.waitHelper.waitForPageLoad();
  }

  async getErrorMessage(): Promise<string> {
    Logger.debug('Getting error message');
    await this.waitForElement(this.errorMessage);
    return await this.getText(this.errorMessage);
  }

  async isErrorMessageDisplayed(): Promise<boolean> {
    return await this.isVisible(this.errorMessage);
  }

  async clickForgotPassword(): Promise<void> {
    Logger.step('Clicking Forgot Password link');
    await this.click(this.forgotPasswordLink);
  }

  async clickSignUp(): Promise<void> {
    Logger.step('Clicking Sign Up link');
    await this.click(this.signupLink);
  }

  async isLoggedIn(): Promise<boolean> {
    Logger.debug('Checking if user is logged in');
    return await this.isVisible(this.userProfileIcon);
  }

  async logout(): Promise<void> {
    Logger.step('Logging out');
    if (await this.isVisible(this.userProfileIcon)) {
      await this.click(this.userProfileIcon);
    }
    await this.click(this.logoutButton);
    await this.waitHelper.waitForPageLoad();
  }
}
