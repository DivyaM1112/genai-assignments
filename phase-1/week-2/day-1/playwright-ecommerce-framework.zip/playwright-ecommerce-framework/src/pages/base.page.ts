import { Page, Locator } from '@playwright/test';
import { Logger } from '../utils/logger';
import { WaitHelper } from '../helpers/wait.helper';

export abstract class BasePage {
  protected waitHelper: WaitHelper;

  constructor(protected page: Page) {
    this.waitHelper = new WaitHelper(page);
  }

  async navigate(url: string): Promise<void> {
    Logger.step(`Navigating to: ${url}`);
    await this.page.goto(url);
    await this.waitHelper.waitForPageLoad();
  }

  async click(locator: Locator): Promise<void> {
    Logger.debug(`Clicking element`);
    await locator.click();
  }

  async fill(locator: Locator, text: string): Promise<void> {
    Logger.debug(`Filling text: ${text}`);
    await locator.fill(text);
  }

  async type(locator: Locator, text: string, delay?: number): Promise<void> {
    Logger.debug(`Typing text: ${text}`);
    await locator.type(text, { delay });
  }

  async getText(locator: Locator): Promise<string> {
    const text = await locator.textContent();
    Logger.debug(`Retrieved text: ${text}`);
    return text || '';
  }

  async isVisible(locator: Locator): Promise<boolean> {
    const visible = await locator.isVisible();
    Logger.debug(`Element visible: ${visible}`);
    return visible;
  }

  async isEnabled(locator: Locator): Promise<boolean> {
    const enabled = await locator.isEnabled();
    Logger.debug(`Element enabled: ${enabled}`);
    return enabled;
  }

  async waitForElement(locator: Locator, timeout?: number): Promise<void> {
    await this.waitHelper.waitForElement(locator, timeout);
  }

  async selectDropdown(locator: Locator, value: string): Promise<void> {
    Logger.debug(`Selecting dropdown value: ${value}`);
    await locator.selectOption(value);
  }

  async getCurrentURL(): Promise<string> {
    const url = this.page.url();
    Logger.debug(`Current URL: ${url}`);
    return url;
  }

  async getTitle(): Promise<string> {
    const title = await this.page.title();
    Logger.debug(`Page title: ${title}`);
    return title;
  }

  async takeScreenshot(name: string): Promise<void> {
    Logger.info(`Taking screenshot: ${name}`);
    await this.page.screenshot({ path: `screenshots/${name}.png`, fullPage: true });
  }

  async scrollToElement(locator: Locator): Promise<void> {
    Logger.debug(`Scrolling to element`);
    await locator.scrollIntoViewIfNeeded();
  }

  async hover(locator: Locator): Promise<void> {
    Logger.debug(`Hovering over element`);
    await locator.hover();
  }

  async pressKey(key: string): Promise<void> {
    Logger.debug(`Pressing key: ${key}`);
    await this.page.keyboard.press(key);
  }
}
