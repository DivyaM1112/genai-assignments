import { Page, Locator } from '@playwright/test';
import { BasePage } from './base.page';
import { Logger } from '../utils/logger';

export class CartPage extends BasePage {
  // Locators
  private readonly cartItems: Locator;
  private readonly itemNames: Locator;
  private readonly itemPrices: Locator;
  private readonly itemQuantities: Locator;
  private readonly removeButtons: Locator;
  private readonly increaseQuantityButtons: Locator;
  private readonly decreaseQuantityButtons: Locator;
  private readonly subtotalAmount: Locator;
  private readonly taxAmount: Locator;
  private readonly totalAmount: Locator;
  private readonly checkoutButton: Locator;
  private readonly continueShoppingButton: Locator;
  private readonly emptyCartMessage: Locator;
  private readonly promoCodeInput: Locator;
  private readonly applyPromoButton: Locator;
  private readonly discountAmount: Locator;

  constructor(page: Page) {
    super(page);
    
    this.cartItems = page.locator('.cart-item, [data-testid="cart-item"]');
    this.itemNames = page.locator('.item-name, .product-name');
    this.itemPrices = page.locator('.item-price, .product-price');
    this.itemQuantities = page.locator('.quantity-input, input[type="number"]');
    this.removeButtons = page.locator('button:has-text("Remove"), .remove-button');
    this.increaseQuantityButtons = page.locator('.increase-quantity, button:has-text("+")');
    this.decreaseQuantityButtons = page.locator('.decrease-quantity, button:has-text("-")');
    this.subtotalAmount = page.locator('.subtotal, [data-testid="subtotal"]').first();
    this.taxAmount = page.locator('.tax, [data-testid="tax"]').first();
    this.totalAmount = page.locator('.total, .grand-total, [data-testid="total"]').first();
    this.checkoutButton = page.locator('button:has-text("Checkout"), button:has-text("Proceed to Checkout")').first();
    this.continueShoppingButton = page.locator('button:has-text("Continue Shopping"), a:has-text("Continue Shopping")').first();
    this.emptyCartMessage = page.locator('.empty-cart, .cart-empty, :has-text("Your cart is empty")').first();
    this.promoCodeInput = page.locator('#promo-code, [name="promoCode"]').first();
    this.applyPromoButton = page.locator('button:has-text("Apply"), .apply-promo').first();
    this.discountAmount = page.locator('.discount, [data-testid="discount"]').first();
  }

  async navigateToCart(): Promise<void> {
    Logger.step('Navigating to Cart Page');
    await this.navigate('/cart');
  }

  async getCartItemCount(): Promise<number> {
    Logger.debug('Getting cart item count');
    return await this.cartItems.count();
  }

  async getItemNames(): Promise<string[]> {
    Logger.debug('Getting cart item names');
    const count = await this.itemNames.count();
    const names: string[] = [];
    
    for (let i = 0; i < count; i++) {
      const name = await this.itemNames.nth(i).textContent();
      if (name) names.push(name.trim());
    }
    
    return names;
  }

  async removeItem(itemName: string): Promise<void> {
    Logger.step(`Removing item from cart: ${itemName}`);
    const item = this.page.locator(`.cart-item:has-text("${itemName}")`).first();
    const removeButton = item.locator('button:has-text("Remove")').first();
    await this.click(removeButton);
    await this.waitHelper.sleep(1000);
  }

  async removeItemByIndex(index: number): Promise<void> {
    Logger.step(`Removing item at index ${index}`);
    await this.click(this.removeButtons.nth(index));
    await this.waitHelper.sleep(1000);
  }

  async updateQuantity(itemName: string, quantity: number): Promise<void> {
    Logger.step(`Updating quantity for ${itemName} to ${quantity}`);
    const item = this.page.locator(`.cart-item:has-text("${itemName}")`).first();
    const quantityInput = item.locator('input[type="number"]').first();
    await this.fill(quantityInput, quantity.toString());
    await this.pressKey('Enter');
    await this.waitHelper.sleep(1000);
  }

  async increaseQuantity(index: number): Promise<void> {
    Logger.step(`Increasing quantity for item at index ${index}`);
    await this.click(this.increaseQuantityButtons.nth(index));
    await this.waitHelper.sleep(1000);
  }

  async decreaseQuantity(index: number): Promise<void> {
    Logger.step(`Decreasing quantity for item at index ${index}`);
    await this.click(this.decreaseQuantityButtons.nth(index));
    await this.waitHelper.sleep(1000);
  }

  async getSubtotal(): Promise<string> {
    Logger.debug('Getting subtotal amount');
    return await this.getText(this.subtotalAmount);
  }

  async getTax(): Promise<string> {
    Logger.debug('Getting tax amount');
    return await this.getText(this.taxAmount);
  }

  async getTotal(): Promise<string> {
    Logger.debug('Getting total amount');
    return await this.getText(this.totalAmount);
  }

  async proceedToCheckout(): Promise<void> {
    Logger.step('Proceeding to checkout');
    await this.click(this.checkoutButton);
    await this.waitHelper.waitForPageLoad();
  }

  async continueShopping(): Promise<void> {
    Logger.step('Continuing shopping');
    await this.click(this.continueShoppingButton);
    await this.waitHelper.waitForPageLoad();
  }

  async isCartEmpty(): Promise<boolean> {
    Logger.debug('Checking if cart is empty');
    return await this.isVisible(this.emptyCartMessage);
  }

  async applyPromoCode(code: string): Promise<void> {
    Logger.step(`Applying promo code: ${code}`);
    await this.fill(this.promoCodeInput, code);
    await this.click(this.applyPromoButton);
    await this.waitHelper.sleep(1000);
  }

  async getDiscount(): Promise<string> {
    Logger.debug('Getting discount amount');
    return await this.getText(this.discountAmount);
  }

  async clearCart(): Promise<void> {
    Logger.step('Clearing all items from cart');
    const count = await this.getCartItemCount();
    
    for (let i = count - 1; i >= 0; i--) {
      await this.removeItemByIndex(0);
      await this.waitHelper.sleep(500);
    }
  }
}
