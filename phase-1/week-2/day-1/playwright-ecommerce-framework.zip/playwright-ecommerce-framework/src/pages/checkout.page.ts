import { Page, Locator } from '@playwright/test';
import { BasePage } from './base.page';
import { Logger } from '../utils/logger';

export class CheckoutPage extends BasePage {
  // Shipping Information Locators
  private readonly firstNameInput: Locator;
  private readonly lastNameInput: Locator;
  private readonly emailInput: Locator;
  private readonly phoneInput: Locator;
  private readonly addressInput: Locator;
  private readonly cityInput: Locator;
  private readonly stateInput: Locator;
  private readonly zipInput: Locator;
  private readonly countrySelect: Locator;

  // Payment Information Locators
  private readonly cardNumberInput: Locator;
  private readonly expiryDateInput: Locator;
  private readonly cvvInput: Locator;
  private readonly cardHolderNameInput: Locator;

  // Buttons
  private readonly continueToPaymentButton: Locator;
  private readonly placeOrderButton: Locator;
  private readonly backToCartButton: Locator;

  // Summary
  private readonly orderSummary: Locator;
  private readonly summaryTotal: Locator;
  private readonly confirmationMessage: Locator;
  private readonly orderNumber: Locator;

  constructor(page: Page) {
    super(page);
    
    // Shipping Information
    this.firstNameInput = page.locator('#firstName, [name="firstName"]').first();
    this.lastNameInput = page.locator('#lastName, [name="lastName"]').first();
    this.emailInput = page.locator('#email, [name="email"]').first();
    this.phoneInput = page.locator('#phone, [name="phone"]').first();
    this.addressInput = page.locator('#address, [name="address"]').first();
    this.cityInput = page.locator('#city, [name="city"]').first();
    this.stateInput = page.locator('#state, [name="state"]').first();
    this.zipInput = page.locator('#zip, [name="zip"], [name="zipCode"]').first();
    this.countrySelect = page.locator('#country, [name="country"]').first();

    // Payment Information
    this.cardNumberInput = page.locator('#cardNumber, [name="cardNumber"]').first();
    this.expiryDateInput = page.locator('#expiryDate, [name="expiryDate"]').first();
    this.cvvInput = page.locator('#cvv, [name="cvv"]').first();
    this.cardHolderNameInput = page.locator('#cardHolderName, [name="cardHolderName"]').first();

    // Buttons
    this.continueToPaymentButton = page.locator('button:has-text("Continue to Payment"), button:has-text("Next")').first();
    this.placeOrderButton = page.locator('button:has-text("Place Order"), button:has-text("Complete Purchase")').first();
    this.backToCartButton = page.locator('button:has-text("Back to Cart"), a:has-text("Back")').first();

    // Summary
    this.orderSummary = page.locator('.order-summary, [data-testid="order-summary"]').first();
    this.summaryTotal = page.locator('.summary-total, .order-total').first();
    this.confirmationMessage = page.locator('.confirmation-message, .success-message').first();
    this.orderNumber = page.locator('.order-number, [data-testid="order-number"]').first();
  }

  async navigateToCheckout(): Promise<void> {
    Logger.step('Navigating to Checkout Page');
    await this.navigate('/checkout');
  }

  async fillShippingInformation(shippingData: {
    firstName: string;
    lastName: string;
    email: string;
    phone: string;
    address: string;
    city: string;
    state: string;
    zip: string;
    country?: string;
  }): Promise<void> {
    Logger.step('Filling shipping information');
    
    await this.fill(this.firstNameInput, shippingData.firstName);
    await this.fill(this.lastNameInput, shippingData.lastName);
    await this.fill(this.emailInput, shippingData.email);
    await this.fill(this.phoneInput, shippingData.phone);
    await this.fill(this.addressInput, shippingData.address);
    await this.fill(this.cityInput, shippingData.city);
    await this.fill(this.stateInput, shippingData.state);
    await this.fill(this.zipInput, shippingData.zip);
    
    if (shippingData.country) {
      await this.selectDropdown(this.countrySelect, shippingData.country);
    }
  }

  async continueToPayment(): Promise<void> {
    Logger.step('Continuing to payment section');
    await this.click(this.continueToPaymentButton);
    await this.waitHelper.waitForPageLoad();
  }

  async fillPaymentInformation(paymentData: {
    cardNumber: string;
    expiryDate: string;
    cvv: string;
    cardHolderName: string;
  }): Promise<void> {
    Logger.step('Filling payment information');
    
    await this.fill(this.cardNumberInput, paymentData.cardNumber);
    await this.fill(this.expiryDateInput, paymentData.expiryDate);
    await this.fill(this.cvvInput, paymentData.cvv);
    await this.fill(this.cardHolderNameInput, paymentData.cardHolderName);
  }

  async placeOrder(): Promise<void> {
    Logger.step('Placing order');
    await this.click(this.placeOrderButton);
    await this.waitHelper.waitForPageLoad();
  }

  async completeCheckout(shippingData: any, paymentData: any): Promise<void> {
    Logger.step('Completing full checkout process');
    
    await this.fillShippingInformation(shippingData);
    await this.continueToPayment();
    await this.fillPaymentInformation(paymentData);
    await this.placeOrder();
  }

  async getSummaryTotal(): Promise<string> {
    Logger.debug('Getting order summary total');
    return await this.getText(this.summaryTotal);
  }

  async isOrderConfirmed(): Promise<boolean> {
    Logger.debug('Checking if order is confirmed');
    return await this.isVisible(this.confirmationMessage);
  }

  async getOrderNumber(): Promise<string> {
    Logger.debug('Getting order number');
    await this.waitForElement(this.orderNumber);
    return await this.getText(this.orderNumber);
  }

  async getConfirmationMessage(): Promise<string> {
    Logger.debug('Getting confirmation message');
    return await this.getText(this.confirmationMessage);
  }

  async backToCart(): Promise<void> {
    Logger.step('Going back to cart');
    await this.click(this.backToCartButton);
    await this.waitHelper.waitForPageLoad();
  }
}
