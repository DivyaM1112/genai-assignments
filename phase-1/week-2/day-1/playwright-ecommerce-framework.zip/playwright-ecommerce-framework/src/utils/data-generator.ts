export class DataGenerator {
  static generateRandomEmail(): string {
    const timestamp = Date.now();
    const random = Math.floor(Math.random() * 10000);
    return `testuser_${timestamp}_${random}@test.com`;
  }

  static generateRandomString(length: number = 10): string {
    const characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
    let result = '';
    for (let i = 0; i < length; i++) {
      result += characters.charAt(Math.floor(Math.random() * characters.length));
    }
    return result;
  }

  static generateRandomNumber(min: number = 1, max: number = 1000): number {
    return Math.floor(Math.random() * (max - min + 1)) + min;
  }

  static generateRandomPhone(): string {
    const areaCode = this.generateRandomNumber(200, 999);
    const middle = this.generateRandomNumber(200, 999);
    const last = this.generateRandomNumber(1000, 9999);
    return `${areaCode}-${middle}-${last}`;
  }

  static generateCreditCard(): {
    number: string;
    cvv: string;
    expiry: string;
  } {
    return {
      number: '4532 1234 5678 9010', // Test card number
      cvv: '123',
      expiry: '12/25',
    };
  }

  static generateAddress(): {
    street: string;
    city: string;
    state: string;
    zip: string;
    country: string;
  } {
    return {
      street: `${this.generateRandomNumber(1, 9999)} Test Street`,
      city: 'Test City',
      state: 'CA',
      zip: '90210',
      country: 'United States',
    };
  }

  static generateUserData() {
    const firstName = `Test${this.generateRandomString(5)}`;
    const lastName = `User${this.generateRandomString(5)}`;
    return {
      firstName,
      lastName,
      email: this.generateRandomEmail(),
      password: 'Test@12345',
      phone: this.generateRandomPhone(),
      fullName: `${firstName} ${lastName}`,
    };
  }
}
