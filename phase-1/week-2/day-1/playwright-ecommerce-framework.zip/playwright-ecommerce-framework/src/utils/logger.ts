export class Logger {
  private static getTimestamp(): string {
    return new Date().toISOString();
  }

  private static formatMessage(level: string, message: string, data?: any): string {
    const timestamp = this.getTimestamp();
    const dataStr = data ? `\n${JSON.stringify(data, null, 2)}` : '';
    return `[${timestamp}] [${level}] ${message}${dataStr}`;
  }

  static info(message: string, data?: any): void {
    console.log('\x1b[36m%s\x1b[0m', this.formatMessage('INFO', message, data));
  }

  static error(message: string, data?: any): void {
    console.error('\x1b[31m%s\x1b[0m', this.formatMessage('ERROR', message, data));
  }

  static warn(message: string, data?: any): void {
    console.warn('\x1b[33m%s\x1b[0m', this.formatMessage('WARN', message, data));
  }

  static success(message: string, data?: any): void {
    console.log('\x1b[32m%s\x1b[0m', this.formatMessage('SUCCESS', message, data));
  }

  static debug(message: string, data?: any): void {
    if (process.env.DEBUG === 'true') {
      console.debug('\x1b[35m%s\x1b[0m', this.formatMessage('DEBUG', message, data));
    }
  }

  static step(stepName: string): void {
    console.log('\x1b[34m%s\x1b[0m', `\n▶ ${stepName}`);
  }
}
