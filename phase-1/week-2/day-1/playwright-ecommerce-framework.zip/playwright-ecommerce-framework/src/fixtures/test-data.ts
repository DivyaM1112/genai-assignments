export const testUsers = {
  validUser: {
    email: 'testuser@example.com',
    password: 'Test@123',
    firstName: 'Test',
    lastName: 'User',
  },
  invalidUser: {
    email: 'invalid@example.com',
    password: 'WrongPassword',
  },
  adminUser: {
    email: 'admin@example.com',
    password: 'Admin@123',
    firstName: 'Admin',
    lastName: 'User',
  },
};

export const testProducts = {
  product1: {
    id: 1,
    name: 'Laptop',
    price: 999.99,
    category: 'Electronics',
  },
  product2: {
    id: 2,
    name: 'Mouse',
    price: 29.99,
    category: 'Accessories',
  },
  product3: {
    id: 3,
    name: 'Keyboard',
    price: 79.99,
    category: 'Accessories',
  },
};

export const testAddresses = {
  validAddress: {
    street: '123 Main Street',
    city: 'New York',
    state: 'NY',
    zip: '10001',
    country: 'United States',
  },
  internationalAddress: {
    street: '456 High Street',
    city: 'London',
    state: 'England',
    zip: 'SW1A 1AA',
    country: 'United Kingdom',
  },
};

export const testPaymentCards = {
  validVisa: {
    number: '4532123456789010',
    cvv: '123',
    expiry: '12/25',
    name: 'Test User',
  },
  validMastercard: {
    number: '5425233430109903',
    cvv: '456',
    expiry: '11/26',
    name: 'Test User',
  },
  expiredCard: {
    number: '4532123456789010',
    cvv: '123',
    expiry: '01/20',
    name: 'Test User',
  },
};

export const promoCodes = {
  valid: 'SAVE10',
  expired: 'EXPIRED2020',
  invalid: 'INVALID123',
};
