import { Page, Locator } from '@playwright/test';
import { Logger } from '../utils/logger';

export class WaitHelper {
  constructor(private page: Page) {}

  async waitForElement(locator: Locator, timeout: number = 10000): Promise<void> {
    Logger.debug(`Waiting for element to be visible`);
    await locator.waitFor({ state: 'visible', timeout });
  }

  async waitForElementToBeHidden(locator: Locator, timeout: number = 10000): Promise<void> {
    Logger.debug(`Waiting for element to be hidden`);
    await locator.waitFor({ state: 'hidden', timeout });
  }

  async waitForPageLoad(timeout: number = 30000): Promise<void> {
    Logger.debug(`Waiting for page to load`);
    await this.page.waitForLoadState('domcontentloaded', { timeout });
    await this.page.waitForLoadState('networkidle', { timeout });
  }

  async waitForURL(url: string | RegExp, timeout: number = 10000): Promise<void> {
    Logger.debug(`Waiting for URL: ${url}`);
    await this.page.waitForURL(url, { timeout });
  }

  async waitForAPIResponse(urlPattern: string | RegExp, timeout: number = 10000): Promise<any> {
    Logger.debug(`Waiting for API response: ${urlPattern}`);
    const response = await this.page.waitForResponse(
      (response) => {
        const url = response.url();
        return typeof urlPattern === 'string' 
          ? url.includes(urlPattern) 
          : urlPattern.test(url);
      },
      { timeout }
    );
    return response.json();
  }

  async sleep(milliseconds: number): Promise<void> {
    Logger.debug(`Sleeping for ${milliseconds}ms`);
    await this.page.waitForTimeout(milliseconds);
  }
}
