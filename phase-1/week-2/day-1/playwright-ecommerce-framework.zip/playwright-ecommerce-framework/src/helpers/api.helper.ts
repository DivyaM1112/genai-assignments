import { APIRequestContext, APIResponse } from '@playwright/test';
import { Logger } from '../utils/logger';

export class ApiHelper {
  constructor(private request: APIRequestContext) {}

  async get(endpoint: string, options?: any): Promise<APIResponse> {
    Logger.step(`GET Request: ${endpoint}`);
    const response = await this.request.get(endpoint, options);
    Logger.info(`Response Status: ${response.status()}`);
    return response;
  }

  async post(endpoint: string, data?: any, options?: any): Promise<APIResponse> {
    Logger.step(`POST Request: ${endpoint}`);
    const response = await this.request.post(endpoint, {
      data,
      ...options,
    });
    Logger.info(`Response Status: ${response.status()}`);
    return response;
  }

  async put(endpoint: string, data?: any, options?: any): Promise<APIResponse> {
    Logger.step(`PUT Request: ${endpoint}`);
    const response = await this.request.put(endpoint, {
      data,
      ...options,
    });
    Logger.info(`Response Status: ${response.status()}`);
    return response;
  }

  async patch(endpoint: string, data?: any, options?: any): Promise<APIResponse> {
    Logger.step(`PATCH Request: ${endpoint}`);
    const response = await this.request.patch(endpoint, {
      data,
      ...options,
    });
    Logger.info(`Response Status: ${response.status()}`);
    return response;
  }

  async delete(endpoint: string, options?: any): Promise<APIResponse> {
    Logger.step(`DELETE Request: ${endpoint}`);
    const response = await this.request.delete(endpoint, options);
    Logger.info(`Response Status: ${response.status()}`);
    return response;
  }

  async validateStatusCode(response: APIResponse, expectedStatus: number): Promise<void> {
    const actualStatus = response.status();
    if (actualStatus !== expectedStatus) {
      Logger.error(`Status code mismatch. Expected: ${expectedStatus}, Got: ${actualStatus}`);
      throw new Error(`Expected status ${expectedStatus} but got ${actualStatus}`);
    }
    Logger.success(`Status code validated: ${actualStatus}`);
  }

  async getResponseBody(response: APIResponse): Promise<any> {
    const body = await response.json();
    Logger.debug('Response Body', body);
    return body;
  }

  async validateSchema(response: APIResponse, schema: any): Promise<void> {
    const body = await response.json();
    // Basic schema validation - can be extended with JSON Schema validator
    for (const key of Object.keys(schema)) {
      if (!(key in body)) {
        throw new Error(`Missing required field: ${key}`);
      }
    }
    Logger.success('Schema validation passed');
  }
}
