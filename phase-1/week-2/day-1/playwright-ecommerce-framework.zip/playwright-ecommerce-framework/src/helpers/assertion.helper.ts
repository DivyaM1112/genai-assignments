import { expect } from '@playwright/test';
import { Logger } from '../utils/logger';

export class AssertionHelper {
  static async assertElementVisible(element: any, elementName: string): Promise<void> {
    Logger.debug(`Asserting ${elementName} is visible`);
    await expect(element).toBeVisible();
    Logger.success(`${elementName} is visible`);
  }

  static async assertElementHidden(element: any, elementName: string): Promise<void> {
    Logger.debug(`Asserting ${elementName} is hidden`);
    await expect(element).toBeHidden();
    Logger.success(`${elementName} is hidden`);
  }

  static async assertElementEnabled(element: any, elementName: string): Promise<void> {
    Logger.debug(`Asserting ${elementName} is enabled`);
    await expect(element).toBeEnabled();
    Logger.success(`${elementName} is enabled`);
  }

  static async assertElementDisabled(element: any, elementName: string): Promise<void> {
    Logger.debug(`Asserting ${elementName} is disabled`);
    await expect(element).toBeDisabled();
    Logger.success(`${elementName} is disabled`);
  }

  static async assertTextEquals(element: any, expectedText: string, elementName: string): Promise<void> {
    Logger.debug(`Asserting ${elementName} has text: ${expectedText}`);
    await expect(element).toHaveText(expectedText);
    Logger.success(`${elementName} has correct text`);
  }

  static async assertTextContains(element: any, expectedText: string, elementName: string): Promise<void> {
    Logger.debug(`Asserting ${elementName} contains text: ${expectedText}`);
    await expect(element).toContainText(expectedText);
    Logger.success(`${elementName} contains correct text`);
  }

  static async assertValueEquals(element: any, expectedValue: string, elementName: string): Promise<void> {
    Logger.debug(`Asserting ${elementName} has value: ${expectedValue}`);
    await expect(element).toHaveValue(expectedValue);
    Logger.success(`${elementName} has correct value`);
  }

  static async assertUrlContains(page: any, expectedUrl: string): Promise<void> {
    Logger.debug(`Asserting URL contains: ${expectedUrl}`);
    await expect(page).toHaveURL(new RegExp(expectedUrl));
    Logger.success('URL is correct');
  }

  static async assertTitleEquals(page: any, expectedTitle: string): Promise<void> {
    Logger.debug(`Asserting page title equals: ${expectedTitle}`);
    await expect(page).toHaveTitle(expectedTitle);
    Logger.success('Page title is correct');
  }

  static assertNumberEquals(actual: number, expected: number, message: string): void {
    Logger.debug(`${message}: Expected ${expected}, Got ${actual}`);
    expect(actual).toBe(expected);
    Logger.success(message);
  }

  static assertGreaterThan(actual: number, minimum: number, message: string): void {
    Logger.debug(`${message}: ${actual} > ${minimum}`);
    expect(actual).toBeGreaterThan(minimum);
    Logger.success(message);
  }

  static assertArrayContains(array: any[], expectedItem: any, message: string): void {
    Logger.debug(message);
    expect(array).toContain(expectedItem);
    Logger.success(message);
  }

  static assertArrayLength(array: any[], expectedLength: number, message: string): void {
    Logger.debug(`${message}: Expected length ${expectedLength}, Got ${array.length}`);
    expect(array).toHaveLength(expectedLength);
    Logger.success(message);
  }
}
